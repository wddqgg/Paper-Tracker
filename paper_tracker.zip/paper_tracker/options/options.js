// options.js
// 默认设置
const DEFAULT_SETTINGS = {
    sheetId: '1Wy1s1mcThJTF6x0YlDVKGZF4YKDzaXDl0UZU_WiK9no',
    autoExtract: true,
    columns: [
        { id: 'title', name: 'Title', enabled: true },
        { id: 'authors', name: 'Authors', enabled: true },
        { id: 'year', name: 'Year', enabled: true },
        { id: 'publication', name: 'Publication', enabled: true },
        { id: 'abstract', name: 'Abstract', enabled: true },
        { id: 'url', name: 'URL', enabled: true },
        { id: 'tags', name: 'Tags', enabled: true },
        { id: 'category', name: 'Category', enabled: true },
        { id: 'customCategory', name: 'Custom Category', enabled: true },
        { id: 'notes', name: 'Notes', enabled: true },
        { id: 'dateAdded', name: 'Date Added', enabled: true }
    ]
};

let draggedItem = null;

// 保存设置
async function saveSettings() {
    const sheetId = document.getElementById('sheetId').value.trim();
    const autoExtract = document.getElementById('autoExtract').checked;
    
    // 获取列设置
    const columnList = document.getElementById('columnList');
    const columns = [...columnList.children].map(item => ({
        id: item.dataset.id,
        name: item.dataset.name,
        enabled: item.querySelector('.column-toggle').checked
    }));

    try {
        await chrome.storage.sync.set({
            sheetId,
            autoExtract,
            columns
        });
        showStatus('Settings saved successfully!');
    } catch (error) {
        showStatus('Error saving settings: ' + error.message, true);
    }
}

// 加载设置
async function loadSettings() {
    try {
        const settings = await chrome.storage.sync.get(DEFAULT_SETTINGS);
        document.getElementById('sheetId').value = settings.sheetId;
        document.getElementById('autoExtract').checked = settings.autoExtract;
        
        // 加载列设置
        renderColumns(settings.columns);
    } catch (error) {
        showStatus('Error loading settings: ' + error.message, true);
    }
}

// 渲染列设置
// options.js
function renderColumns(columns) {
    const columnList = document.getElementById('columnList');
    columnList.innerHTML = '';

    columns.forEach(column => {
        const columnDiv = document.createElement('div');
        columnDiv.className = 'column-item';
        columnDiv.draggable = true;
        columnDiv.dataset.id = column.id;
        columnDiv.dataset.name = column.name;

        columnDiv.innerHTML = `
            <input type="checkbox" class="column-toggle" 
                   ${column.enabled ? 'checked' : ''}>
            <span class="column-name">${column.name}</span>
            <span class="drag-handle">⠿</span>  <!-- 使用Unicode字符 -->
        `;

        // 拖拽事件
        columnDiv.addEventListener('dragstart', handleDragStart);
        columnDiv.addEventListener('dragend', handleDragEnd);
        columnDiv.addEventListener('dragover', handleDragOver);
        columnDiv.addEventListener('drop', handleDrop);

        columnList.appendChild(columnDiv);
    });
}

// 拖拽相关函数
function handleDragStart(e) {
    draggedItem = e.target;
    e.target.classList.add('dragging');
}

function handleDragEnd(e) {
    e.target.classList.remove('dragging');
    draggedItem = null;
}

function handleDragOver(e) {
    e.preventDefault();
}

function handleDrop(e) {
    e.preventDefault();
    const dropTarget = e.target.closest('.column-item');
    if (dropTarget && draggedItem !== dropTarget) {
        const list = document.getElementById('columnList');
        const items = [...list.children];
        const draggedIndex = items.indexOf(draggedItem);
        const dropIndex = items.indexOf(dropTarget);
        
        if (draggedIndex < dropIndex) {
            dropTarget.parentNode.insertBefore(draggedItem, dropTarget.nextSibling);
        } else {
            dropTarget.parentNode.insertBefore(draggedItem, dropTarget);
        }
    }
}

// 重置设置
async function resetSettings() {
    try {
        await chrome.storage.sync.set(DEFAULT_SETTINGS);
        loadSettings();
        showStatus('Settings reset to default!');
    } catch (error) {
        showStatus('Error resetting settings: ' + error.message, true);
    }
}

// 显示状态消息
function showStatus(message, isError = false) {
    const status = document.getElementById('status');
    status.textContent = message;
    status.className = `status ${isError ? 'error' : 'success'}`;
    setTimeout(() => {
        status.className = 'status';
        status.textContent = '';
    }, 3000);
}

// 初始化页面
document.addEventListener('DOMContentLoaded', () => {
    loadSettings();
    
    document.getElementById('save').addEventListener('click', saveSettings);
    document.getElementById('reset').addEventListener('click', resetSettings);
});