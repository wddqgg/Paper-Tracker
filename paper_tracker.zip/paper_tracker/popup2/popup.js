document.addEventListener('DOMContentLoaded', function() {
    const autoModeToggle = document.getElementById('autoMode');
    const extractButton = document.getElementById('extractButton');
    const saveButton = document.getElementById('saveButton');
    const statusDiv = document.getElementById('status');

    // 自动模式切换
    autoModeToggle.addEventListener('change', () => {
        if (autoModeToggle.checked) {
            extractPaperInfo();
        }
    });

    // 提取按钮点击事件
    extractButton.addEventListener('click', () => {
        extractPaperInfo();
    });

    // 保存按钮点击事件
    saveButton.addEventListener('click', () => {
        savePaperInfo();
    });

    // 快捷键支持
    document.addEventListener('keydown', (e) => {
        // Ctrl+E: 提取信息
        if (e.ctrlKey && e.key === 'e') {
            e.preventDefault();
            extractPaperInfo();
        }
        // Ctrl+Enter: 保存信息
        if (e.ctrlKey && e.key === 'Enter') {
            e.preventDefault();
            savePaperInfo();
        }
    });

    // 初始化：获取当前页面URL
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs[0]) {
            document.getElementById('url').value = tabs[0].url;
            // 如果开启了自动模式，自动提取信息
            if (autoModeToggle.checked) {
                extractPaperInfo();
            }
        }
    });
});

// 提取论文信息
async function extractPaperInfo() {
    try {
        showStatus('Extracting paper information...', 'info');

        const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
        const response = await chrome.tabs.sendMessage(tab.id, {action: 'extractInfo'});

        if (response.success) {
            document.getElementById('title').value = response.data.title || '';
            document.getElementById('authors').value = response.data.authors || '';
            document.getElementById('year').value = response.data.year || '';
            document.getElementById('conference').value = response.data.conference || '';
            document.getElementById('abstract').value = response.data.abstract || '';
            
            showStatus('Information extracted successfully!', 'success');
        } else {
            throw new Error(response.error || 'Failed to extract information');
        }
    } catch (error) {
        console.error('Error extracting paper info:', error);
        showStatus('Failed to extract information: ' + error.message, 'error');
    }
}

// 保存论文信息
async function savePaperInfo() {
    try {
        showStatus('Saving paper information...', 'info');

        const paperData = {
            title: document.getElementById('title').value,
            authors: document.getElementById('authors').value,
            year: document.getElementById('year').value,
            conference: document.getElementById('conference').value,
            abstract: document.getElementById('abstract').value,
            url: document.getElementById('url').value
        };

        if (!paperData.title) {
            throw new Error('Title is required');
        }

        const response = await chrome.runtime.sendMessage({
            action: 'savePaper',
            data: paperData
        });

        if (response.success) {
            showStatus('Paper saved successfully!', 'success');
            setTimeout(() => window.close(), 1500);
        } else {
            throw new Error(response.error || 'Failed to save paper');
        }
    } catch (error) {
        console.error('Error saving paper:', error);
        showStatus('Failed to save paper: ' + error.message, 'error');
    }
}

// 显示状态消息
function showStatus(message, type = 'info') {
    const statusDiv = document.getElementById('status');
    statusDiv.textContent = message;
    statusDiv.className = 'status-message ' + type;
    
    if (type === 'success' || type === 'error') {
        setTimeout(() => {
            statusDiv.style.display = 'none';
        }, 3000);
    }
}