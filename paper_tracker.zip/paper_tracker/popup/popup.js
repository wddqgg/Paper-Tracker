// popup.js
// 定义默认设置，与 background.js 保持一致
const DEFAULT_SETTINGS = {
    columns: [
        { id: 'title', name: 'Title', enabled: true },
        { id: 'authors', name: 'Authors', enabled: true },
        { id: 'year', name: 'Year', enabled: true },
        { id: 'publication', name: 'Publication', enabled: true },
        { id: 'abstract', name: 'Abstract', enabled: true },
        { id: 'url', name: 'URL', enabled: true },
        { id: 'tags', name: 'Tags', enabled: true },
        { id: 'category', name: 'Category', enabled: true },
        { id: 'customCategory', name: 'Custom Category', enabled: true },
        { id: 'notes', name: 'Notes', enabled: true },
        { id: 'dateAdded', name: 'Date Added', enabled: true }
    ]
};

// 添加在文件开头的函数
async function isValidPage() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab && tab.url && (
        tab.url.includes('arxiv.org') ||
        tab.url.includes('.pdf') ||
        tab.url.includes('ieee.org') ||
        tab.url.includes('acm.org') ||
        tab.url.includes('sciencedirect.com') ||
        tab.url.includes('springer.com')
    );
}

// 添加在文件开头的辅助函数
function processValue(value) {
    if (Array.isArray(value)) {
        return value.join(', ');
    }
    return value || '';
}


// 添加处理论文信息的函数
function handlePaperInfo(paperInfo) {
    if (!paperInfo) return;
    
    console.log('Received paper info:', paperInfo);
    
    // 填充表单字段
    Object.keys(paperInfo).forEach(key => {
        const input = document.getElementById(key);
        if (input) {
            input.value = processValue(paperInfo[key]);
        }
    });
    
    showStatus('Paper information loaded successfully!', 'success');
}

// 获取启用的列配置
async function getActiveColumns() {
    const settings = await chrome.storage.sync.get(DEFAULT_SETTINGS);
    return settings.columns.filter(col => col.enabled) || 
           DEFAULT_SETTINGS.columns.filter(col => col.enabled);
}

// 生成表单字段
async function generateFormFields() {
    const paperInfo = document.getElementById('paperInfo');
    const activeColumns = await getActiveColumns();
    
    paperInfo.innerHTML = ''; // 清空现有字段

    activeColumns.forEach(column => {
        if (column.id !== 'dateAdded') { // 不显示自动生成的日期字段
            const formGroup = document.createElement('div');
            formGroup.className = 'form-group';

            const label = document.createElement('label');
            label.textContent = `${column.name}:`;

            let input;
            if (column.id === 'abstract' || column.id === 'notes') {
                input = document.createElement('textarea');
            } else {
                input = document.createElement('input');
                input.type = 'text';
            }
            input.id = column.id;

            formGroup.appendChild(label);
            formGroup.appendChild(input);
            paperInfo.appendChild(formGroup);
        }
    });
}

document.addEventListener('DOMContentLoaded', async function() {
    // 获取元素
    if (!await isValidPage()) {
        showStatus('This page is not supported', 'error');
        return;
    }
    
    
    const extractButton = document.getElementById('extractButton');
    const saveButton = document.getElementById('saveButton');
    const autoModeCheckbox = document.getElementById('autoMode');
    const pinButton = document.getElementById('pinButton');
    const statusDiv = document.getElementById('status');

    // 生成表单字段
    await generateFormFields();

    // 添加消息监听器
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        console.log('Received message in popup:', message);
        
        if (message.action === 'PAPER_INFO') {
            handlePaperInfo(message.data);
        }
        
        // 返回 true 以保持消息通道开放
        return true;
    });

    // 通知 background.js 窗口已准备就绪
    chrome.runtime.sendMessage({
        action: 'WINDOW_READY',
        windowId: chrome.windows.WINDOW_ID_CURRENT
    });    

    // 加载自动模式状态
    chrome.storage.sync.get(['autoMode'], (result) => {
        autoModeCheckbox.checked = result.autoMode || false;
    });

    // 自动模式切换
    autoModeCheckbox.addEventListener('change', (e) => {
        chrome.storage.sync.set({ autoMode: e.target.checked });
    });

    // 提取信息
    extractButton.addEventListener('click', async () => {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        
        try {
            const response = await chrome.tabs.sendMessage(tab.id, { action: 'getPaperInfo' });
            console.log('Received response:', response);
    
            if (!response.success) {
                throw new Error(response.error || 'Failed to extract information');
            }
    
            // 使用返回的数据
            const paperInfo = response.data;
            
            // 填充表单，使用 processValue 函数处理数据
            const activeColumns = await getActiveColumns();
            activeColumns.forEach(column => {
                const input = document.getElementById(column.id);
                if (input && paperInfo[column.id] !== undefined) {
                    input.value = processValue(paperInfo[column.id]);
                }
            });
    
            showStatus('Information extracted successfully!', 'success');
        } catch (error) {
            console.error('Extraction failed:', error);
            showStatus('Failed to extract information: ' + error.message, 'error');
        }
    });

    // 保存到表格
    saveButton.addEventListener('click', async () => {
        const activeColumns = await getActiveColumns();
        const data = {};
        
        activeColumns.forEach(column => {
            const input = document.getElementById(column.id);
            if (input) {
                data[column.id] = input.value;
            }
        });

        try {
            const response = await chrome.runtime.sendMessage({
                action: 'savePaper',
                data: data
            });

            if (response.success) {
                showStatus('Paper saved successfully!', 'success');
            } else {
                throw new Error(response.error || 'Failed to save paper');
            }
        } catch (error) {
            console.error('Save failed:', error);
            showStatus('Failed to save paper: ' + error.message, 'error');
        }
    });


// 钉住功能
// popup.js 中的钉住按钮事件监听器
pinButton.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    try {
        console.log('Sending createFloatingWindow message to tab:', tab.id);
        const activeColumns = await getActiveColumns();
        const data = {};
        activeColumns.forEach(column => {
            const input = document.getElementById(column.id);
            if (input) {
                data[column.id] = input.value;
            }
        });

        const response = await chrome.tabs.sendMessage(tab.id, { 
            action: 'createFloatingWindow',
            data: data
        });
        
        console.log('Floating window response:', response);
        
        if (!response || response.error) {
            throw new Error(response?.error || 'Failed to create floating window');
        }

        // 显示成功消息但不关闭窗口
        showStatus('Floating window created successfully!', 'success');
    } catch (error) {
        console.error('Failed to create floating window:', error);
        showStatus('Failed to create floating window: ' + error.message, 'error');
    }
});

    // 状态显示函数
    function showStatus(message, type = 'success') {
        if (!statusDiv) return;  // 添加安全检查
        
        statusDiv.textContent = message;
        statusDiv.className = `status ${type}`;
        statusDiv.style.opacity = '1';
        
        if (type !== 'error') {  // 错误消息保持显示
            setTimeout(() => {
                if (statusDiv) {  // 再次检查元素是否存在
                    statusDiv.style.opacity = '0';
                }
            }, 3000);
        }
    }

    // 初始加载时尝试提取信息
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
        try {
            const response = await chrome.tabs.sendMessage(tab.id, { action: 'getPaperInfo' });
            console.log('Auto extraction response:', response);
            
            if (response && response.success && response.data) {
                handlePaperInfo(response.data);
            }
        } catch (error) {
            console.error('Auto extraction failed:', error);
            // 自动提取失败时不显示错误消息
        }
    }
});