// core/extractors/sites/NatureExtractor.js

import { BaseExtractor } from '../BaseExtractor';

export class NatureExtractor extends BaseExtractor {
    constructor() {
        super();
    }

    extractTitle() {
        const title = document.querySelector('h1.c-article-title')?.textContent.trim();
        return title || super.extractTitle();
    }

    extractAuthors() {
        const authorElements = document.querySelectorAll('ul.c-article-author-list li');
        if (authorElements.length > 0) {
            return Array.from(authorElements)
                .map(el => el.textContent.trim())
                .join(', ');
        }
        return super.extractAuthors();
    }

    extractYear() {
        const dateElement = document.querySelector('.c-article-info-details time');
        if (dateElement) {
            const dateMatch = dateElement.textContent.match(/\d{4}/);
            if (dateMatch) {
                return dateMatch[0];
            }
        }
        return super.extractYear();
    }

    extractAbstract() {
        const abstract = document.querySelector('.c-article-section__content')?.textContent.trim();
        return abstract || super.extractAbstract();
    }

    extractPublication() {  // 改名
        const pubElement = document.querySelector('.c-journal-title');
        if (pubElement) {
            return pubElement.textContent.trim();
        }
        return super.extractPublication();
    }    
}