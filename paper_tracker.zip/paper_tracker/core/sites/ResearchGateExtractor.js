// core/extractors/sites/ResearchGateExtractor.js

import { BaseExtractor } from '../BaseExtractor';

export class ResearchGateExtractor extends BaseExtractor {
    constructor() {
        super();
    }

    extractTitle() {
        const title = document.querySelector('h1.research-detail-header-section__title')?.textContent.trim();
        return title || super.extractTitle();
    }

    extractAuthors() {
        const authorElements = document.querySelectorAll('.research-detail-header-section__author-list a');
        if (authorElements.length > 0) {
            return Array.from(authorElements)
                .map(el => el.textContent.trim())
                .join(', ');
        }
        return super.extractAuthors();
    }

    extractAbstract() {
        const abstract = document.querySelector('.research-detail-header-section__abstract')?.textContent.trim();
        return abstract || super.extractAbstract();
    }

    // ResearchGate 特有的方法
    extractCitations() {
        const citationElement = document.querySelector('.nova-e-text--color-grey-700');
        if (citationElement && citationElement.textContent.includes('Citations')) {
            const citationMatch = citationElement.textContent.match(/\d+/);
            return citationMatch ? parseInt(citationMatch[0]) : 0;
        }
        return 0;
    }

    extractPublication() {  // 改名
        const pubElement = document.querySelector('.research-detail-header-section__source');
        if (pubElement) {
            return pubElement.textContent.trim();
        }
        return super.extractPublication();
    }


    extractReads() {
        const readElement = document.querySelector('.nova-e-text--color-grey-700');
        if (readElement && readElement.textContent.includes('Reads')) {
            const readMatch = readElement.textContent.match(/\d+/);
            return readMatch ? parseInt(readMatch[0]) : 0;
        }
        return 0;
    }

    // 重写extract方法以包含特有字段
    async extract() {
        const baseData = await super.extract();
        return {
            ...baseData,
            citations: this.extractCitations(),
            reads: this.extractReads()
        };
    }
}