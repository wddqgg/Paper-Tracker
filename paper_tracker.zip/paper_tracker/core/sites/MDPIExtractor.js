// core/extractors/sites/MDPIExtractor.js

import { BaseExtractor } from '../BaseExtractor';

export class MDPIExtractor extends BaseExtractor {
    constructor() {
        super();
    }

    extractTitle() {
        const title = document.querySelector('h1.title')?.textContent.trim();
        return title || super.extractTitle();
    }

    extractAuthors() {
        const authorElements = document.querySelectorAll('.art-authors .author');
        if (authorElements.length > 0) {
            return Array.from(authorElements)
                .map(el => el.textContent.trim())
                .join(', ');
        }
        return super.extractAuthors();
    }

    extractAbstract() {
        const abstract = document.querySelector('.art-abstract')?.textContent.trim();
        return abstract || super.extractAbstract();
    }

    // MDPI 特有的方法
    extractKeywords() {
        const keywordElements = document.querySelectorAll('.art-keywords .keyword');
        return Array.from(keywordElements)
            .map(el => el.textContent.trim());
    }

    extractDOI() {
        const doiElement = document.querySelector('.art-doi');
        return doiElement ? doiElement.textContent.trim().replace('DOI:', '').trim() : '';
    }

    extractPublication() {
        const journalElement = document.querySelector('.journal-title');
        if (journalElement) {
            return journalElement.textContent.trim();
        }
        return super.extractPublication();
    }

    // 重写extract方法以包含特有字段
    async extract() {
        const baseData = await super.extract();
        return {
            ...baseData,
            keywords: this.extractKeywords(),
            doi: this.extractDOI(),
            journal: this.extractJournal()
        };
    }
}