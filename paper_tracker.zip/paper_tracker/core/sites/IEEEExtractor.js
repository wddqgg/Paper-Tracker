// core/extractors/sites/IEEEExtractor.js

import { BaseExtractor } from '../BaseExtractor';

export class IEEEExtractor extends BaseExtractor {
    constructor() {
        super();
    }

    extractTitle() {
        const title = document.querySelector('h1.document-title')?.textContent.trim();
        return title || super.extractTitle();
    }

    extractAuthors() {
        const authorElements = document.querySelectorAll('span.authors-info-name');
        if (authorElements.length > 0) {
            return Array.from(authorElements)
                .map(el => el.textContent.trim())
                .join(', ');
        }
        return super.extractAuthors();
    }

    extractYear() {
        const dateElement = document.querySelector('.article-date');
        if (dateElement) {
            const dateMatch = dateElement.textContent.match(/\d{4}/);
            if (dateMatch) {
                return dateMatch[0];
            }
        }
        return super.extractYear();
    }

    extractPublication() {
        const confElement = document.querySelector('.publisher-conference-info');
        if (confElement) {
            return confElement.textContent.trim();
        }
        
        const journalElement = document.querySelector('.publisher-journal-info');
        if (journalElement) {
            return journalElement.textContent.trim();
        }
        
        return super.extractPublication();
    }

    extractAbstract() {
        const abstract = document.querySelector('.abstract-text')?.textContent.trim();
        return abstract || super.extractAbstract();
    }
}