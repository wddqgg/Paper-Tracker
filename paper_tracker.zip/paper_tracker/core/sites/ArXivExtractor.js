// core/extractors/sites/ArXivExtractor.js

import { BaseExtractor } from '../BaseExtractor';

export class ArXivExtractor extends BaseExtractor {
    constructor() {
        super();
    }

    extractTitle() {
        const title = document.querySelector('h1.title')?.textContent.replace('Title:', '').trim();
        return title || super.extractTitle();
    }

    extractAuthors() {
        const authors = document.querySelector('.authors')?.textContent.replace('Authors:', '').trim();
        return authors || super.extractAuthors();
    }

    extractYear() {
        // 首先尝试从URL中获取年份
        const yearMatch = window.location.href.match(/\d{4}/);
        if (yearMatch) {
            return yearMatch[0];
        }

        // 然后尝试从日期行获取
        const dateElement = document.querySelector('.dateline');
        if (dateElement) {
            const dateMatch = dateElement.textContent.match(/\d{4}/);
            if (dateMatch) {
                return dateMatch[0];
            }
        }

        return super.extractYear();
    }

    extractPublication() {
        const comments = document.querySelector('.comments');
        const primaryCategory = document.querySelector('.primary-subject');
        
        let publication = '';
        
        // 尝试从评论中获取会议/期刊信息
        if (comments) {
            publication = comments.textContent.trim();
        }
        
        // 如果没有会议/期刊信息，使用 arXiv 分类
        if (!publication && primaryCategory) {
            publication = `arXiv: ${primaryCategory.textContent.trim()}`;
        }
        
        return publication || super.extractVenue();
    }

    extractAbstract() {
        const abstract = document.querySelector('.abstract')?.textContent.replace('Abstract:', '').trim();
        return abstract || super.extractAbstract();
    }
}