// core/extractors/sites/WileyExtractor.js

import { BaseExtractor } from '../BaseExtractor';

export class WileyExtractor extends BaseExtractor {
    constructor() {
        super();
    }

    extractTitle() {
        const title = document.querySelector('h1.citation__title')?.textContent.trim();
        return title || super.extractTitle();
    }

    extractAuthors() {
        const authorElements = document.querySelectorAll('.article-header__authors-list a');
        if (authorElements.length > 0) {
            return Array.from(authorElements)
                .map(el => el.textContent.trim())
                .join(', ');
        }
        return super.extractAuthors();
    }

    extractAbstract() {
        const abstract = document.querySelector('.article-section__content')?.textContent.trim();
        return abstract || super.extractAbstract();
    }

    // Wiley 特有的方法
    extractDOI() {
        const doiElement = document.querySelector('.epub-doi');
        return doiElement ? doiElement.textContent.trim().replace('DOI:', '').trim() : '';
    }

    extractPublication() {  // 改名
        const pubElement = document.querySelector('.citation__journal-title');
        if (pubElement) {
            return pubElement.textContent.trim();
        }
        return super.extractPublication();
    }

    // 重写extract方法以包含特有字段
    async extract() {
        const baseData = await super.extract();
        return {
            ...baseData,
            doi: this.extractDOI(),
            journal: this.extractJournal()
        };
    }
}