// core/extractors/sites/DBLP.js

import { BaseExtractor } from '../BaseExtractor';

export class DBLP extends BaseExtractor {
    constructor() {
        super();
    }

    extractTitle() {
        const titleElement = document.querySelector('.title');
        if (titleElement) {
            return titleElement.textContent.trim();
        }
        return super.extractTitle();
    }

    extractAuthors() {
        const authors = Array.from(document.querySelectorAll('.authors a'));
        if (authors.length > 0) {
            return authors.map(author => author.textContent.trim()).join(', ');
        }
        return super.extractAuthors();
    }

    extractYear() {
        const yearElement = document.querySelector('.year');
        if (yearElement) {
            return yearElement.textContent.trim();
        }
        return super.extractYear();
    }

    extractPublication() {  // 改名
        const pubElement = document.querySelector('.venue');
        if (pubElement) {
            return pubElement.textContent.trim();
        }
        
        // 尝试从会议/期刊信息获取
        const venueElement = document.querySelector('.journal, .conference');
        if (venueElement) {
            return venueElement.textContent.trim();
        }
        
        return super.extractPublication();
    }

    async extract() {
        const baseData = await super.extract();
        return {
            ...baseData,
            venue: this.extractVenue()
        };
    }
}