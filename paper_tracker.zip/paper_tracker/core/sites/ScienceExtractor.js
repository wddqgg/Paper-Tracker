// core/extractors/sites/ScienceExtractor.js

import { BaseExtractor } from '../BaseExtractor';

export class ScienceExtractor extends BaseExtractor {
    constructor() {
        super();
    }

    extractTitle() {
        const title = document.querySelector('h1.article__headline')?.textContent.trim();
        return title || super.extractTitle();
    }

    extractAuthors() {
        const authorElements = document.querySelectorAll('.article__author-list .article-author-list__name');
        if (authorElements.length > 0) {
            return Array.from(authorElements)
                .map(el => el.textContent.trim())
                .join(', ');
        }
        return super.extractAuthors();
    }

    extractAbstract() {
        const abstract = document.querySelector('.section-paragraph')?.textContent.trim();
        return abstract || super.extractAbstract();
    }

    extractPublication() {  // 改名
        const pubElement = document.querySelector('.journal-info');
        if (pubElement) {
            return pubElement.textContent.trim();
        }
        return super.extractPublication();
    }    
}