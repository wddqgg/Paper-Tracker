// core/extractors/sites/GoogleScholar.js

import { BaseExtractor } from '../BaseExtractor';

export class GoogleScholar extends BaseExtractor {
    constructor() {
        super();
    }

    extractTitle() {
        // 首先尝试获取主标题
        const titleElement = document.querySelector('.gs_rt a');
        if (titleElement) {
            return titleElement.textContent.trim();
        }
        return super.extractTitle();
    }

    extractAuthors() {
        const authorElement = document.querySelector('.gs_a');
        if (authorElement) {
            // 提取作者部分（在第一个 '-' 之前的部分）
            const authorText = authorElement.textContent.split('-')[0];
            return authorText.trim();
        }
        return super.extractAuthors();
    }

    extractYear() {
        const infoElement = document.querySelector('.gs_a');
        if (infoElement) {
            const yearMatch = infoElement.textContent.match(/\d{4}/);
            return yearMatch ? yearMatch[0] : '';
        }
        return super.extractYear();
    }

    extractAbstract() {
        const abstractElement = document.querySelector('.gs_rs');
        if (abstractElement) {
            return abstractElement.textContent.trim();
        }
        return super.extractAbstract();
    }

    extractPublication() {  // 改名
        const pubElement = document.querySelector('.gs_a');
        if (pubElement) {
            return pubElement.textContent.trim();
        }
        return super.extractPublication();
    }
    
    extractCitations() {
        const citationElement = document.querySelector('.gs_fl a:first-child');
        if (citationElement) {
            const citationMatch = citationElement.textContent.match(/\d+/);
            return citationMatch ? parseInt(citationMatch[0]) : 0;
        }
        return 0;
    }

    async extract() {
        const baseData = await super.extract();
        return {
            ...baseData,
            citations: this.extractCitations()
        };
    }
}