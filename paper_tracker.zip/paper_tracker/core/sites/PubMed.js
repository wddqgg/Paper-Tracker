// core/extractors/sites/PubMed.js

import { BaseExtractor } from '../BaseExtractor';

export class PubMed extends BaseExtractor {
    constructor() {
        super();
    }

    extractTitle() {
        const titleElement = document.querySelector('.heading-title');
        if (titleElement) {
            return titleElement.textContent.trim();
        }
        return super.extractTitle();
    }

    extractAuthors() {
        const authors = Array.from(document.querySelectorAll('.authors-list .authors-list-item'));
        if (authors.length > 0) {
            return authors.map(author => author.textContent.trim()).join(', ');
        }
        return super.extractAuthors();
    }

    extractAbstract() {
        const abstractElement = document.querySelector('.abstract-content');
        if (abstractElement) {
            return abstractElement.textContent.trim();
        }
        return super.extractAbstract();
    }

    extractPublication() {
        const pubElement = document.querySelector('.journal-title');
        if (pubElement) {
            return pubElement.textContent.trim();
        }
        
        // 尝试从引用信息中获取
        const citationElement = document.querySelector('.citation-doi');
        if (citationElement) {
            return citationElement.textContent.split('.')[0].trim();
        }
        
        return super.extractPublication();
    }

    async extract() {
        const baseData = await super.extract();
        return {
            ...baseData,
            journal: this.extractJournal()
        };
    }
}