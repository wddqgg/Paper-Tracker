// core/extractors/sites/JSTORExtractor.js

import { BaseExtractor } from '../BaseExtractor';

export class JSTORExtractor extends BaseExtractor {
    constructor() {
        super();
    }

    extractTitle() {
        const title = document.querySelector('.title-container h1')?.textContent.trim();
        return title || super.extractTitle();
    }

    extractAuthors() {
        const authorElements = document.querySelectorAll('.author-name');
        if (authorElements.length > 0) {
            return Array.from(authorElements)
                .map(el => el.textContent.trim())
                .join(', ');
        }
        return super.extractAuthors();
    }

    extractAbstract() {
        const abstract = document.querySelector('.abstract')?.textContent.trim();
        return abstract || super.extractAbstract();
    }

    extractPublication() {  // 改名
        const pubElement = document.querySelector('.journal-info');
        if (pubElement) {
            return pubElement.textContent.trim();
        }
        return super.extractPublication();
    }    
}