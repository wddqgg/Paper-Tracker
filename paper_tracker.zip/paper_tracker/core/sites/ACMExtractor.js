// core/extractors/sites/ACMExtractor.js

import { BaseExtractor } from '../BaseExtractor';

export class ACMExtractor extends BaseExtractor {
    constructor() {
        super();
    }

    extractTitle() {
        const title = document.querySelector('h1.citation__title')?.textContent.trim();
        return title || super.extractTitle();
    }

    extractAuthors() {
        const authorElements = document.querySelectorAll('span.loa__author-name');
        if (authorElements.length > 0) {
            return Array.from(authorElements)
                .map(el => el.textContent.trim())
                .join(', ');
        }
        return super.extractAuthors();
    }

    extractPublication() {
        const pubElement = document.querySelector('.conference-info');
        if (pubElement) {
            return pubElement.textContent.trim();
        }
        return super.extractPublication();
    }

    extractAbstract() {
        const abstract = document.querySelector('.abstractInFull')?.textContent.trim();
        return abstract || super.extractAbstract();
    }
}