// core/extractors/sites/ScienceDirectExtractor.js

import { BaseExtractor } from '../BaseExtractor';

export class ScienceDirectExtractor extends BaseExtractor {
    constructor() {
        super();
    }

    extractTitle() {
        const title = document.querySelector('.title-text')?.textContent.trim();
        return title || super.extractTitle();
    }

    extractAuthors() {
        const authorElements = document.querySelectorAll('.author-group .content span.text');
        if (authorElements.length > 0) {
            return Array.from(authorElements)
                .map(el => el.textContent.trim())
                .join(', ');
        }
        return super.extractAuthors();
    }

    extractYear() {
        const dateElement = document.querySelector('.publication-volume-info');
        if (dateElement) {
            const dateMatch = dateElement.textContent.match(/\d{4}/);
            if (dateMatch) {
                return dateMatch[0];
            }
        }
        return super.extractYear();
    }

    extractAbstract() {
        const abstract = document.querySelector('.abstract.author')?.textContent.trim();
        return abstract || super.extractAbstract();
    }

    extractPublication() {  // 改名
        const pubElement = document.querySelector('.publication-title-link');
        if (pubElement) {
            return pubElement.textContent.trim();
        }
        
        // 尝试从期刊信息获取
        const journalElement = document.querySelector('.journal-title');
        if (journalElement) {
            return journalElement.textContent.trim();
        }
        
        return super.extractPublication();
    }    
}