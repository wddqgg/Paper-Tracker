// core/extractors/BaseExtractor.js

class BaseExtractor {
    constructor() {
        this.metaSelectors = {
            title: [
                'meta[name="citation_title"]',
                'meta[property="og:title"]',
                'meta[name="dc.title"]'
            ],
            authors: [
                'meta[name="citation_author"]',
                'meta[name="author"]',
                'meta[name="dc.creator"]'
            ],
            year: [
                'meta[name="citation_publication_date"]',
                'meta[name="citation_date"]',
                'meta[name="dc.date"]'
            ],
            abstract: [
                'meta[name="description"]',
                'meta[name="citation_abstract"]',
                'meta[property="og:description"]'
            ],
            publication: [
                'meta[name="citation_journal_title"]',
                'meta[name="citation_conference"]',
                'meta[name="citation_conference_title"]',
                'meta[name="prism.publicationName"]',
                'meta[name="citation_inbook_title"]'
            ]
        };
    }

    // 基础元数据提取方法
    extractMetaContent(selectors) {
        for (const selector of selectors) {
            const element = document.querySelector(selector);
            if (element && element.content) {
                return element.content.trim();
            }
        }
        return '';
    }

    // 从元素中提取文本
    extractTextContent(selector) {
        const element = document.querySelector(selector);
        return element ? element.textContent.trim() : '';
    }

    // Schema.org 数据提取
    extractSchemaData() {
        const schemaScript = document.querySelector('script[type="application/ld+json"]');
        if (schemaScript) {
            try {
                return JSON.parse(schemaScript.textContent);
            } catch (e) {
                console.error('Error parsing Schema.org data:', e);
            }
        }
        return null;
    }

    // 主要提取方法
    async extract() {
        return {
            title: this.extractTitle(),
            authors: this.extractAuthors(),
            year: this.extractYear(),
            abstract: this.extractAbstract(),
            Publication: this.extractPublication(),
            url: window.location.href
        };
    }

    // 各字段的提取方法
    extractTitle() {
        return this.extractMetaContent(this.metaSelectors.title);
    }

    extractAuthors() {
        return this.extractMetaContent(this.metaSelectors.authors);
    }

    extractYear() {
        const dateStr = this.extractMetaContent(this.metaSelectors.year);
        return dateStr ? dateStr.match(/\d{4}/)?.[0] || '' : '';
    }

    extractAbstract() {
        return this.extractMetaContent(this.metaSelectors.abstract);
    }

    extractPublication() {
        return this.extractMetaContent(this.metaSelectors.publication);
    }
}

// 将类设置为全局变量
if (typeof window !== 'undefined') {
    window.BaseExtractor = BaseExtractor;
}