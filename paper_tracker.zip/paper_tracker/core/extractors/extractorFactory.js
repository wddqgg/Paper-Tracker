// core/extractors/extractorFactory.js

import { BaseExtractor } from './BaseExtractor';
import { GoogleScholar } from './sites/GoogleScholar';
import { DBLP } from './sites/DBLP';
import { PubMed } from './sites/PubMed';
import { ArXivExtractor } from './sites/ArXivExtractor';
import { IEEEExtractor } from './sites/IEEEExtractor';
import { ACMExtractor } from './sites/ACMExtractor';
import { ScienceDirectExtractor } from './sites/ScienceDirectExtractor';
import { SpringerExtractor } from './sites/SpringerExtractor';
import { NatureExtractor } from './sites/NatureExtractor';
import { ScienceExtractor } from './sites/ScienceExtractor';
import { JSTORExtractor } from './sites/JSTORExtractor';
import { ResearchGateExtractor } from './sites/ResearchGateExtractor';
import { WileyExtractor } from './sites/WileyExtractor';
import { MDPIExtractor } from './sites/MDPIExtractor';

export class ExtractorFactory {
    static getExtractor(url) {
        const hostname = new URL(url).hostname;

        if (hostname.includes('scholar.google.com')) {
            return new GoogleScholar();
        }
        if (hostname.includes('dblp.org')) {
            return new DBLP();
        }
        if (hostname.includes('pubmed.ncbi.nlm.nih.gov')) {
            return new PubMed();
        }        if (hostname.includes('arxiv.org')) {
            return new ArXivExtractor();
        }
        if (hostname.includes('ieee.org')) {
            return new IEEEExtractor();
        }
        if (hostname.includes('acm.org')) {
            return new ACMExtractor();
        }
        if (hostname.includes('sciencedirect.com')) {
            return new ScienceDirectExtractor();
        }
        if (hostname.includes('springer.com')) {
            return new SpringerExtractor();
        }
        if (hostname.includes('nature.com')) {
            return new NatureExtractor();
        }
        if (hostname.includes('science.org')) {
            return new ScienceExtractor();
        }
        if (hostname.includes('jstor.org')) {
            return new JSTORExtractor();
        }
        if (hostname.includes('researchgate.net')) {
            return new ResearchGateExtractor();
        }
        if (hostname.includes('wiley.com')) {
            return new WileyExtractor();
        }
        if (hostname.includes('mdpi.com')) {
            return new MDPIExtractor();
        }
        return new BaseExtractor();
    }
}