
const DEFAULT_SETTINGS = {
    sheetId: '1Wy1s1mcThJTF6x0YlDVKGZF4YKDzaXDl0UZU_WiK9no',
    autoExtract: true,
    columns: [
        { id: 'title', name: 'Title', enabled: true },
        { id: 'authors', name: 'Authors', enabled: true },
        { id: 'year', name: 'Year', enabled: true },
        { id: 'publication', name: 'Publication', enabled: true },
        { id: 'abstract', name: 'Abstract', enabled: true },
        { id: 'url', name: 'URL', enabled: true },
        { id: 'dateAdded', name: 'Date Added', enabled: true },
        { id: 'tags', name: 'Tags', enabled: true },
        { id: 'category', name: 'Category', enabled: true },
        { id: 'customCategory', name: 'Custom Category', enabled: true },
        { id: 'notes', name: 'Notes', enabled: true }
    ]
};

// 添加在这里
let savedPapers = [];

const CONFIG = {
    SPREADSHEET_ID: DEFAULT_SETTINGS.sheetId
};

let trackerWindow = null;
let pendingPaperInfo = null; // 添加在文件顶部，与 trackerWindow 变量放在一起   
// 获取当前启用的列配置
async function getActiveColumns() {
    const settings = await chrome.storage.sync.get(DEFAULT_SETTINGS);
    return settings.columns || DEFAULT_SETTINGS.columns;
}

// 从存储中加载设置
function loadSettings() {
    chrome.storage.sync.get(['sheetId'], function(result) {
        if (result.sheetId) {
            CONFIG.SPREADSHEET_ID = result.sheetId;
            console.log('Loaded sheet ID from settings:', CONFIG.SPREADSHEET_ID);
        }
    });
}

// 监听设置变化
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'sync' && changes.sheetId) {
        CONFIG.SPREADSHEET_ID = changes.sheetId.newValue;
        console.log('Sheet ID updated:', CONFIG.SPREADSHEET_ID);
    }
});

// [保持原有的 createTrackerWindow 函数不变]
// 在 createTrackerWindow 函数中添加更多日志
async function createTrackerWindow(tab) {
    try {
        console.log('Creating tracker window for tab:', tab);
        
        if (trackerWindow) {
            console.log('Existing tracker window found, focusing it');
            await chrome.windows.update(trackerWindow.id, { focused: true });
            return;
        }

        const width = 400;
        const height = 600;
        
        const currentWindow = await chrome.windows.getCurrent();
        const left = currentWindow.left + (currentWindow.width - width);
        const top = currentWindow.top;

        console.log('Creating new tracker window');
        trackerWindow = await chrome.windows.create({
            url: chrome.runtime.getURL('popup/popup.html'),
            type: 'popup',
            width: width,
            height: height,
            left: left,
            top: top,
            focused: true
        });

        // 修改 arXiv ID 提取逻辑
        if (tab?.url?.includes('arxiv.org')) {
            console.log('ArXiv page detected, fetching metadata');
            // 提取 arXiv ID 的新方法
            const arxivId = extractArxivId(tab.url);
            console.log('ArXiv ID:', arxivId);
            
            if (arxivId) {
                const paperInfo = await fetchArxivMetadata(arxivId);
                console.log('Fetched paper info:', paperInfo);
                
                if (paperInfo) {
                    // 等待窗口创建完成
                    await new Promise(resolve => setTimeout(resolve, 1000));
                    
                    // 获取新创建的窗口中的所有标签页
                    const tabs = await chrome.tabs.query({windowId: trackerWindow.id});
                    if (tabs.length > 0) {
                        // 向新窗口发送消息
                        chrome.tabs.sendMessage(tabs[0].id, {
                            action: 'PAPER_INFO',
                            data: paperInfo
                        });
                    }
                }
            }
        }

        // 监听窗口关闭
        chrome.windows.onRemoved.addListener(function windowClosedListener(windowId) {
            if (windowId === trackerWindow.id) {
                console.log('Tracker window closed');
                trackerWindow = null;
                chrome.windows.onRemoved.removeListener(windowClosedListener);
            }
        });
    } catch (error) {
        console.error('Error creating tracker window:', error);
    }    
}

// 在点击事件监听器中添加日志
chrome.action.onClicked.addListener(async (tab) => {
    console.log('Extension icon clicked for tab:', tab);
    await createTrackerWindow(tab);
});

// 添加在文件中合适的位置，比如其他辅助函数附近
function checkDuplicatePaper(newPaper) {
    return savedPapers.some(paper => {
        // 检查关键字段是否匹配
        const titleMatch = paper.title?.toLowerCase() === newPaper.title?.toLowerCase();
        const authorsMatch = paper.authors === newPaper.authors;
        const yearMatch = paper.year === newPaper.year;
        const publicationMatch = paper.publication === newPaper.publication;
        const urlMatch = paper.url === newPaper.url;

        // 记录详细的匹配信息
        if (titleMatch || authorsMatch || yearMatch || publicationMatch || urlMatch) {
            console.log('Potential duplicate found:', {
                titleMatch,
                authorsMatch,
                yearMatch,
                publicationMatch,
                urlMatch,
                existingPaper: paper,
                newPaper
            });
        }

        return titleMatch && authorsMatch && yearMatch && publicationMatch && urlMatch;
    });
}

// 从存储中加载已保存的论文
chrome.storage.local.get(['savedPapers'], function(result) {
    if (result.savedPapers) {
        savedPapers = result.savedPapers;
        console.log('Loaded saved papers from storage:', savedPapers.length);
    }
});

// 更新存储中的论文数据
function updateSavedPapersStorage() {
    chrome.storage.local.set({ savedPapers: savedPapers }, function() {
        console.log('Saved papers updated in storage:', savedPapers.length);
    });
}

// 添加新的辅助函数来提取 arXiv ID
function extractArxivId(url) {
    // 处理多种可能的 URL 格式
    const patterns = [
        /arxiv\.org\/pdf\/(\d+\.\d+)/,
        /arxiv\.org\/abs\/(\d+\.\d+)/,
        /(\d+\.\d+)/
    ];

    for (const pattern of patterns) {
        const match = url.match(pattern);
        if (match && match[1]) {
            return match[1];
        }
    }
    return null;
}

// 添加新的函数用于获取 arXiv 元数据
// 更新 fetchArxivMetadata 函数
async function fetchArxivMetadata(arxivId) {
    try {
        console.log(`Fetching metadata for arXiv ID: ${arxivId}`);
        const response = await fetch(`https://export.arxiv.org/api/query?id_list=${arxivId}`);
        
        if (!response.ok) {
            throw new Error(`ArXiv API responded with status: ${response.status}`);
        }

        const text = await response.text();
        console.log('Received XML response:', text);

        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(text, "text/xml");
        
        // 检查是否有解析错误
        const parseError = xmlDoc.querySelector('parsererror');
        if (parseError) {
            throw new Error('XML parsing failed');
        }

        const entry = xmlDoc.querySelector('entry');
        if (!entry) {
            throw new Error('No entry found in ArXiv response');
        }

        // 提取数据
        const title = entry.querySelector('title')?.textContent?.trim();
        const authors = Array.from(entry.querySelectorAll('author name'))
            .map(author => author.textContent.trim())
            .join(', ');
        const published = entry.querySelector('published')?.textContent;
        const year = published ? new Date(published).getFullYear() : '';
        const abstract = entry.querySelector('summary')?.textContent?.trim();
        const categories = Array.from(entry.querySelectorAll('category'))
            .map(cat => cat.getAttribute('term'))
            .join(', ');

        const paperInfo = {
            title,
            authors,
            year,
            publication: 'arXiv',
            abstract,
            url: `https://arxiv.org/abs/${arxivId}`,
            category: categories,
            tags: [],
            notes: []
        };

        console.log('Parsed paper info:', paperInfo);
        return paperInfo;
    } catch (error) {
        console.error('Error fetching arXiv metadata:', error);
        return null;
    }
}






function checkIfPaperPage(url) {
    if (!url) return false;
    
    const paperDomains = [
        'arxiv.org',
        'ieee.org',
        'acm.org',
        'sciencedirect.com',
        'springer.com',
        'researchgate.net',
        'nature.com',
        'science.org',
        'scholar.google.com'
    ];

    try {
        const urlObj = new URL(url);
        return paperDomains.some(domain => urlObj.hostname.includes(domain));
    } catch (error) {
        console.error('Error checking paper page:', error);
        return false;
    }
}

// [保持原有的 getAuthToken 函数不变]
async function getAuthToken() {
    // ... 原有代码保持不变 ...
    try {
        console.log('Starting getAuthToken process...');
        
        return new Promise((resolve, reject) => {
            chrome.identity.getAuthToken({ interactive: true }, (token) => {
                if (chrome.runtime.lastError) {
                    console.error('Auth error:', chrome.runtime.lastError);
                    reject(chrome.runtime.lastError);
                    return;
                }
                console.log('Token obtained successfully');
                resolve(token);
            });
        });
    } catch (error) {
        console.error('Auth error:', error);
        throw error;
    }    
}

// 修改后的保存论文信息到表格函数
async function savePaperToSheet(paperData) {
    try {
        const token = await getAuthToken();
        if (!token) {
            throw new Error('Failed to get auth token');
        }

        console.log('Token obtained, preparing to save data...');

        // 首先获取所有现有数据
        const existingDataResponse = await fetch(
            `https://sheets.googleapis.com/v4/spreadsheets/${CONFIG.SPREADSHEET_ID}/values/Sheet1`,
            {
                headers: { 'Authorization': `Bearer ${token}` }
            }
        );

        if (!existingDataResponse.ok) {
            throw new Error(`Failed to get existing data: ${existingDataResponse.statusText}`);
        }

        const existingData = await existingDataResponse.json();
        const rows = existingData.values || [];
        
        // 获取标题列的索引（假设标题始终在第一列）
        const titleIndex = 0;
        
        // 查找匹配的行
        let matchingRowIndex = -1;
        if (rows.length > 1) { // 如果有数据行（不只是表头）
            matchingRowIndex = rows.findIndex((row, index) => 
                index > 0 && row[titleIndex] === paperData.title
            );
        }

        // 获取当前启用的列配置
        const columns = await getActiveColumns();
        const enabledColumns = columns.filter(col => col.enabled);

        // 构建新数据行
        const newRow = enabledColumns.map(col => {
            switch(col.id) {
                case 'dateAdded':
                    return new Date().toISOString().split('T')[0];
                case 'tags':
                    return (paperData.tags || []).join(', ');
                case 'notes':
                    // 如果找到匹配的行，合并笔记
                    if (matchingRowIndex > 0) {
                        const existingNotes = rows[matchingRowIndex][enabledColumns.findIndex(c => c.id === 'notes')] || '[]';
                        const existingNotesArray = JSON.parse(existingNotes);
                        const newNotesArray = paperData.notes || [];
                        return JSON.stringify([...existingNotesArray, ...newNotesArray]);
                    }
                    return JSON.stringify(paperData.notes || []);
                default:
                    return String(paperData[col.id] || '');
            }
        });

        if (matchingRowIndex > 0) {
            // 更新已存在的行
            const updateRange = `Sheet1!A${matchingRowIndex + 1}:${String.fromCharCode(65 + enabledColumns.length - 1)}${matchingRowIndex + 1}`;
            const updateResponse = await fetch(
                `https://sheets.googleapis.com/v4/spreadsheets/${CONFIG.SPREADSHEET_ID}/values/${updateRange}?valueInputOption=USER_ENTERED`,
                {
                    method: 'PUT',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        values: [newRow]
                    })
                }
            );

            if (!updateResponse.ok) {
                throw new Error(`Failed to update existing row: ${updateResponse.statusText}`);
            }
        } else {
            // 添加新行
            const appendResponse = await fetch(
                `https://sheets.googleapis.com/v4/spreadsheets/${CONFIG.SPREADSHEET_ID}/values/Sheet1:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`,
                {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        values: [newRow]
                    })
                }
            );

            if (!appendResponse.ok) {
                throw new Error(`Failed to append new row: ${appendResponse.statusText}`);
            }
        }

        // 保存标签到存储中
        await saveTagsToStorage(paperData.tags || []);
        savedPapers.push(paperData);
        updateSavedPapersStorage(); // 更新存储        
        
        return { success: true };
    } catch (error) {
        console.error('Save operation failed:', error);
        throw error;
    }
}

// 辅助函数：比较两个数组是否相等
function arraysEqual(a, b) {
    if (!a || !b || a.length !== b.length) return false;
    return a.every((val, index) => val === b[index]);
}

// [保持原有的 saveTagsToStorage 函数不变]
async function saveTagsToStorage(tags) {
    try {
        const result = await chrome.storage.sync.get(['savedTags']);
        const savedTags = new Set(result.savedTags || []);
        tags.forEach(tag => savedTags.add(tag));
        await chrome.storage.sync.set({ 
            savedTags: Array.from(savedTags) 
        });
    } catch (error) {
        console.error('Error saving tags to storage:', error);
    }    
}

// 修改测试函数以支持动态列
async function testSheetsAPI() {
    try {
        const token = await getAuthToken();
        if (!token) {
            throw new Error('No auth token available');
        }

        console.log('Testing Sheets API access...');

        const readResponse = await fetch(
            `https://sheets.googleapis.com/v4/spreadsheets/${CONFIG.SPREADSHEET_ID}`,
            {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }
        );

        if (!readResponse.ok) {
            throw new Error(`Read test failed: ${readResponse.statusText}`);
        }

        const readResult = await readResponse.json();
        console.log('Read test successful:', readResult);

        // 获取启用的列并创建测试数据
        const columns = await getActiveColumns();
        const enabledColumns = columns.filter(col => col.enabled);
        const testData = [enabledColumns.map(col => {
            switch(col.id) {
                case 'title': return 'API Test';
                case 'authors': return 'Test Entry';
                case 'year': return new Date().getFullYear().toString();
                case 'publication': return 'Test Publication';
                case 'abstract': return 'Test Abstract';
                case 'url': return 'https://test.com';
                case 'dateAdded': return new Date().toISOString().split('T')[0];
                case 'tags': return 'test-tag1, test-tag2';
                case 'category': return 'methodology';
                case 'customCategory': return '';
                case 'notes': return '[]';
                default: return '';
            }
        })];

        const writeResponse = await fetch(
            `https://sheets.googleapis.com/v4/spreadsheets/${CONFIG.SPREADSHEET_ID}/values/Sheet1:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`,
            {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    values: testData
                })
            }
        );

        if (!writeResponse.ok) {
            throw new Error(`Write test failed: ${writeResponse.statusText}`);
        }

        const writeResult = await writeResponse.json();
        console.log('Write test successful:', writeResult);
        return true;
    } catch (error) {
        console.error('API test failed:', error);
        return false;
    }
}

// 在 background.js 中的消息监听器
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('Received message:', request);

    // 处理重复检查请求
    if (request.action === "checkDuplicate") {
        const isDuplicate = checkDuplicatePaper(request.data);
        sendResponse({ isDuplicate });
        return true;
    }   
    
    // 处理保存论文请求
    if (request.action === "savePaper") {
        (async () => {
            try {
                // 首先检查是否重复
                if (checkDuplicatePaper(request.data)) {
                    sendResponse({ 
                        success: false, 
                        error: 'This paper information has already been saved!' 
                    });
                    return;
                }

                console.log('Starting save operation...');
                const result = await savePaperToSheet(request.data);
                
                if (result.success) {
                    // 保存成功后添加到本地缓存
                    savedPapers.push(request.data);
                }
                
                console.log('Save operation completed:', result);
                sendResponse({ success: true, result });
            } catch (error) {
                console.error('Operation failed:', error);
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }
    
    // 处理获取已保存标签请求
    if (request.action === "getSavedTags") {
        chrome.storage.sync.get(['savedTags'], function(result) {
            sendResponse({ success: true, tags: result.savedTags || [] });
        });
        return true;
    }

    // 处理窗口准备就绪的消息
    if (request.action === 'WINDOW_READY') {
        console.log('Window ready message received');
        if (sender.tab && trackerWindow && sender.tab.windowId === trackerWindow.id) {
            // 如果有待发送的论文信息，发送它
            if (pendingPaperInfo) {
                chrome.tabs.sendMessage(sender.tab.id, {
                    action: 'PAPER_INFO',
                    data: pendingPaperInfo
                });
                pendingPaperInfo = null;
            }
        }
        return true;
    }
});

// [保持原有的安装/更新处理不变]
chrome.runtime.onInstalled.addListener(async () => {
    console.log('Extension installed/updated');
    
    loadSettings();
    
    try {
        const testResult = await testSheetsAPI();
        console.log('Initial API test result:', testResult);
        
        if (!testResult) {
            console.error('Initial API test failed');
        }
    } catch (error) {
        console.error('Error during installation test:', error);
    }

    chrome.alarms.create('keepAlive', { periodInMinutes: 1 });
});

// [保持原有的保活机制不变]
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'keepAlive') {
        console.log('Keep alive ping:', new Date().toISOString());
    }
});