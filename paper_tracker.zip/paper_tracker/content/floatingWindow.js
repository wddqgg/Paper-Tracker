// content/floatingWindow.js


// 添加等待函数
async function waitForPaperExtractor(timeout = 5000) {
    const startTime = Date.now();
    while (Date.now() - startTime < timeout) {
        if (window.PaperExtractor || window.top?.PaperExtractor) {
            return true;
        }
        await new Promise(resolve => setTimeout(resolve, 100));
    }
    return false;
}
// 检查依赖是否正确加载
async function checkDependencies() {
    const hasExtractor = await waitForPaperExtractor();
    if (!hasExtractor) {
        const error = new Error('Required dependency PaperExtractor not found');
        console.error(error, {
            windowProperties: Object.keys(window),
            topWindowProperties: window !== window.top ? Object.keys(window.top) : null,
            location: window.location.href,
            isIframe: window !== window.top
        });
        throw error;
    }
}

class FloatingWindow {
    static REQUIRED_FIELDS = ['title'];

    constructor(initialData = null) {
        this.initializeAsync(initialData);
    }   

    // 在这里添加 safeQuerySelector 方法
    safeQuerySelector(parent, selector) {
        if (!parent) return null;
        try {
            return parent.querySelector(selector);
        } catch (error) {
            console.error(`Error querying selector ${selector}:`, error);
            return null;
        }
    }   
    
    async initializeAsync(initialData) {
        try {
            // 等待 PaperExtractor 加载
            await this.waitForDependencies();
            
            // 初始化表单字段
            this.initializeFormFields();
            
            // 创建和初始化窗口
            await this.createFloatingWindow(initialData);
            
            // 设置拖拽功能
            this.initDragFeature();
            
            // 如果有初始数据，填充表单
            if (initialData && typeof initialData === 'object') {
                this.fillFormWithData(initialData);
            }
            
            // 如果是 PDF 页面且没有初始数据，尝试自动提取
            if (this.isPDFPage() && !initialData) {
                await this.autoExtractPDFInfo();
            }
        } catch (error) {
            console.error('FloatingWindow initialization failed:', error);
            throw error;
        }
    }

    // 添加这个新方法
    async createFloatingWindow(initialData) {
        try {
            // 添加在方法开始处
            const existingWindow = document.getElementById('paper-tracker-float');
            if (existingWindow) {
                existingWindow.remove();
            }               
            const existingContainer = document.getElementById('paper-tracker-container');
            if (existingContainer) {
                existingContainer.remove();
            }

            const isPDF = this.isPDFPage();
            console.log('Creating floating window, isPDF:', isPDF, 'initialData:', initialData);

            if (isPDF) {
                // 为 PDF 页面创建特殊的容器
                const container = document.createElement('div');
                container.id = 'paper-tracker-container';
                container.style.cssText = `
                    position: fixed !important;
                    top: 0 !important;
                    right: 0 !important;
                    width: 320px !important;
                    height: 100% !important;
                    z-index: 999999 !important;
                    background: white !important;
                    box-shadow: -2px 0 5px rgba(0,0,0,0.1) !important;
                    display: block !important; /* 添加这行 */
                    visibility: visible !important; /* 添加这行 */                    
                `;
                document.body.appendChild(container);
                await this.createWindow(container);

                // 尝试自动提取信息
                if (!initialData) {
                    await this.autoExtractPDFInfo();
                }
            } else {
                await this.createWindow(document.body);
            }
        } catch (error) {
            console.error('Error creating floating window:', error);
            throw error;
        }
    }


    async waitForDependencies(timeout = 5000) {
        const startTime = Date.now();
        
        while (Date.now() - startTime < timeout) {
            if (window.PaperExtractor || window.top?.PaperExtractor) {
                return true;
            }
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        
        throw new Error('Required dependency PaperExtractor not found');
    }    

    initializeFormFields() {
        const uniqueId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        this.formFields = {
            title: `paper-title-${uniqueId}`,
            authors: `paper-authors-${uniqueId}`,
            year: `paper-year-${uniqueId}`,
            publication: `paper-publication-${uniqueId}`,
            abstract: `paper-abstract-${uniqueId}`,
            url: `paper-url-${uniqueId}`
        };
    }

    isPDFPage() {
        return window.location.pathname.includes('/pdf/');
    }    

    async autoExtractPDFInfo() {
        try {
            const extractor = new window.PaperExtractor();
            const paperInfo = await extractor.extractAll();
            if (paperInfo) {
                console.log('Auto-extracted paper info:', paperInfo);
                this.fillFormWithData(paperInfo);
                this.showStatus('Information extracted successfully!', 'success');
            }
        } catch (error) {
            console.error('Auto extraction failed:', error);
            this.showStatus('Failed to auto-extract information', 'error');
        }
    }

    // Debug helper
    _debug(message, data = null) {
        const debugInfo = {
            timestamp: new Date().toISOString(),
            message,
            data,
            formFields: this.formFields,
            windowContext: {
                isIframe: window !== window.top,
                location: window.location.href,
                isPDF: this.isPDFPage()
            }
        };
        console.log('FloatingWindow Debug:', debugInfo);
    }    

    createWindow(parent) {
        const formFields = this.formFields;      
        const windowHTML = `
        <div id="paper-tracker-float" class="paper-tracker-window">
            <div class="paper-tracker-header">
                <span>Paper Information</span>
                <div class="window-controls">
                    <button class="minimize-btn">-</button>
                    <button class="close-btn">×</button>
                </div>
            </div>
            <div class="paper-tracker-content">
                <div class="mode-switch">
                    <label class="switch" for="autoMode">
                        <input type="checkbox" id="autoMode">
                        <span class="slider round"></span>
                    </label>
                    <span>Auto Mode</span>
                </div>
                <div id="paperInfo">
                    <div class="form-group">
                        <label for="${formFields.title}">Title:</label>
                        <input type="text" id="${formFields.title}" name="title" />
                    </div>
                    <div class="form-group">
                        <label for="${formFields.authors}">Authors:</label>
                        <input type="text" id="${formFields.authors}" name="authors" />
                    </div>
                    <div class="form-group">
                        <label for="${formFields.year}">Year:</label>
                        <input type="text" id="${formFields.year}" name="year" />
                    </div>
                    <div class="form-group">
                        <label for="${formFields.publication}">Publication:</label>
                        <input type="text" id="${formFields.publication}" name="publication" />
                    </div>
                    <div class="form-group">
                        <label for="${formFields.abstract}">Abstract:</label>
                        <textarea id="${formFields.abstract}" name="abstract"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="${formFields.url}">URL:</label>
                        <input type="text" id="${formFields.url}" name="url" />
                    </div>
    
                    <!-- 标签和分类功能 -->
                    <div class="form-group">
                        <label for="tagInput">Tags:</label>
                        <div class="tag-container">
                            <div class="tag-input-wrapper">
                                <input type="text" id="tagInput" name="tagInput" placeholder="Add tags..." />
                                <button id="addTagBtn" class="tag-add-btn">+</button>
                            </div>
                            <div id="tagList" class="tag-list"></div>
                        </div>
                    </div>
    
                    <div class="form-group">
                        <label for="categorySelect">Category:</label>
                        <select id="categorySelect" name="category">
                            <option value="">Select category...</option>
                            <option value="methodology">Research Methodology</option>
                            <option value="related">Related Work</option>
                            <option value="implementation">Implementation</option>
                            <option value="evaluation">Evaluation</option>
                            <option value="custom">Custom...</option>
                        </select>
                        <input type="text" id="customCategory" name="customCategory" class="hidden" placeholder="Enter custom category" />
                    </div>
                </div>
    
                <!-- 笔记功能 -->
                <div class="notes-section">
                    <div class="notes-header">
                        <h3>Notes & Comments</h3>
                        <button id="addNoteBtn" class="note-add-btn">Add Note</button>
                    </div>
                    <div id="notesList" class="notes-list"></div>
                </div>
    
                <div class="button-group">
                    <button id="extractButton">Extract Info</button>
                    <button id="saveButton">Save to Sheet</button>
                </div>
                <div id="status" class="status"></div>
            </div>
        </div>
    `;

        // 添加样式
        const style = document.createElement('style');
        style.textContent = `
            /* 原有样式保持不变 */
            .paper-tracker-window {
                position: fixed !important;
                top: 20px !important;
                right: 20px !important;
                width: 300px !important;
                background: white !important;
                border: 1px solid #ccc !important;
                border-radius: 8px !important;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1) !important;
                z-index: 9999999 !important;
                font-family: -apple-system, system-ui, sans-serif !important;
            }

            .paper-tracker-header {
                padding: 10px !important;
                background: #f5f5f5 !important;
                border-bottom: 1px solid #ddd !important;
                display: flex !important;
                justify-content: space-between !important;
                align-items: center !important;
                cursor: move !important;
                border-radius: 8px 8px 0 0 !important;
                user-select: none !important;
            }

            .window-controls button {
                margin-left: 5px !important;
                border: none !important;
                background: none !important;
                cursor: pointer !important;
                padding: 0 5px !important;
                font-size: 16px !important;
            }

            .window-controls button:hover {
                background: rgba(0,0,0,0.1) !important;
                border-radius: 4px !important;
            }

            .paper-tracker-content {
                padding: 15px !important;
                max-height: 500px !important;
                overflow-y: auto !important;
            }

            .paper-tracker-window.minimized .paper-tracker-content {
                display: none !important;
            }

            .mode-switch {
                margin-bottom: 15px !important;
                display: flex !important;
                align-items: center !important;
                gap: 10px !important;
            }

            .form-group {
                margin-bottom: 15px !important;
            }

            .form-group label {
                display: block !important;
                margin-bottom: 5px !important;
                font-weight: 500 !important;
                color: #333 !important;
            }

            .form-group input,
            .form-group textarea {
                width: 100% !important;
                padding: 8px !important;
                border: 1px solid #ddd !important;
                border-radius: 4px !important;
                box-sizing: border-box !important;
                font-size: 14px !important;
                transition: all 0.3s ease !important;
            }

            .form-group input:focus,
            .form-group textarea:focus {
                outline: none !important;
                border-color: #4285f4 !important;
                box-shadow: 0 0 0 2px rgba(66, 133, 244, 0.2) !important;
            }

            .form-group textarea {
                min-height: 100px !important;
                resize: vertical !important;
            }

            .button-group {
                display: flex !important;
                gap: 10px !important;
                margin-top: 15px !important;
            }

            .button-group button {
                flex: 1 !important;
                padding: 8px !important;
                background: #4285f4 !important;
                color: white !important;
                border: none !important;
                border-radius: 4px !important;
                cursor: pointer !important;
                font-weight: 500 !important;
                transition: background 0.3s ease !important;
            }

            .button-group button:hover {
                background: #3367d6 !important;
            }

            .status {
                margin-top: 10px !important;
                padding: 8px !important;
                border-radius: 4px !important;
                text-align: center !important;
                transition: opacity 0.3s ease !important;
                opacity: 0 !important;
            }

            .status.success {
                background-color: #e8f5e9 !important;
                color: #2e7d32 !important;
                border: 1px solid #a5d6a7 !important;
                opacity: 1 !important;
            }

            .status.error {
                background-color: #ffebee !important;
                color: #c62828 !important;
                border: 1px solid #ffcdd2 !important;
                opacity: 1 !important;
            }

            /* Switch styles */
            .switch {
                position: relative !important;
                display: inline-block !important;
                width: 50px !important;
                height: 24px !important;
            }

            .switch input {
                opacity: 0 !important;
                width: 0 !important;
                height: 0 !important;
            }

            .slider {
                position: absolute !important;
                cursor: pointer !important;
                top: 0 !important;
                left: 0 !important;
                right: 0 !important;
                bottom: 0 !important;
                background-color: #ccc !important;
                transition: .4s !important;
                border-radius: 34px !important;
            }

            .slider:before {
                position: absolute !important;
                content: "" !important;
                height: 18px !important;
                width: 18px !important;
                left: 3px !important;
                bottom: 3px !important;
                background-color: white !important;
                transition: .4s !important;
                border-radius: 50% !important;
            }

            input:checked + .slider {
                background-color: #4285f4 !important;
            }

            input:checked + .slider:before {
                transform: translateX(26px) !important;
            }
        

            /* 新增：标签和笔记相关样式 */
            .tag-container {
                margin-top: 5px !important;
            }

            .tag-input-wrapper {
                display: flex !important;
                gap: 8px !important;
                margin-bottom: 8px !important;
            }

            .tag-add-btn {
                padding: 4px 8px !important;
                background: #4285f4 !important;
                color: white !important;
                border: none !important;
                border-radius: 4px !important;
                cursor: pointer !important;
            }

            .tag-list {
                display: flex !important;
                flex-wrap: wrap !important;
                gap: 6px !important;
                margin-bottom: 10px !important;
            }

            .tag {
                background: #e1f5fe !important;
                color: #0277bd !important;
                padding: 4px 8px !important;
                border-radius: 12px !important;
                font-size: 12px !important;
                display: flex !important;
                align-items: center !important;
                gap: 4px !important;
            }

            .tag-remove {
                cursor: pointer !important;
                color: #0277bd !important;
                font-weight: bold !important;
            }

            .hidden {
                display: none !important;
            }

            .notes-section {
                margin-top: 20px !important;
                border-top: 1px solid #eee !important;
                padding-top: 15px !important;
            }

            .notes-header {
                display: flex !important;
                justify-content: space-between !important;
                align-items: center !important;
                margin-bottom: 10px !important;
            }

            .notes-header h3 {
                margin: 0 !important;
                font-size: 14px !important;
                color: #333 !important;
            }

            .note-add-btn {
                padding: 4px 12px !important;
                background: #4285f4 !important;
                color: white !important;
                border: none !important;
                border-radius: 4px !important;
                cursor: pointer !important;
            }

            .notes-list {
                display: flex !important;
                flex-direction: column !important;
                gap: 10px !important;
                max-height: 200px !important;
                overflow-y: auto !important;
            }

            .note-item {
                background: #f8f9fa !important;
                border-left: 3px solid #4285f4 !important;
                padding: 10px !important;
                border-radius: 4px !important;
            }

            .note-header {
                display: flex !important;
                justify-content: space-between !important;
                margin-bottom: 5px !important;
                font-size: 12px !important;
                color: #666 !important;
            }

            .note-content {
                font-size: 14px !important;
                white-space: pre-wrap !important;
            }

            .note-actions {
                display: flex !important;
                gap: 8px !important;
            }

            .note-edit, .note-delete {
                cursor: pointer !important;
                color: #666 !important;
            }

            .note-dialog {
                position: fixed !important;
                top: 0 !important;
                left: 0 !important;
                right: 0 !important;
                bottom: 0 !important;
                background: rgba(0,0,0,0.5) !important;
                display: flex !important;
                justify-content: center !important;
                align-items: center !important;
                z-index: 1000000 !important;
            }

            .note-dialog-content {
                background: white !important;
                padding: 20px !important;
                border-radius: 8px !important;
                width: 90% !important;
                max-width: 500px !important;
            }

            .note-dialog textarea {
                width: 100% !important;
                min-height: 100px !important;
                margin-bottom: 10px !important;
                padding: 8px !important;
                border: 1px solid #ddd !important;
                border-radius: 4px !important;
                resize: vertical !important;
            }

            .note-dialog-actions {
                display: flex !important;
                justify-content: flex-end !important;
                gap: 8px !important;
            }

            .note-dialog button {
                padding: 6px 12px !important;
                border: none !important;
                border-radius: 4px !important;
                cursor: pointer !important;
            }

            .note-dialog .save-note {
                background: #4285f4 !important;
                color: white !important;
            }

            .note-dialog .cancel-note {
                background: #f1f3f4 !important;
                color: #333 !important;
            }
        `;

        document.head.appendChild(style);
        const container = document.createElement('div');
        container.innerHTML = windowHTML;
        parent.appendChild(container.firstElementChild);

        this.initializeControls();
    }

    initializeControls() {

        const window = document.getElementById('paper-tracker-float');
        if (!window) {
            console.error('Failed to find paper-tracker-float element');
            return;
        }
    
        // 原有的控件初始化
        const minimizeBtn = this.safeQuerySelector(window, '.minimize-btn');
        const closeBtn = this.safeQuerySelector(window, '.close-btn');
        const extractBtn = this.safeQuerySelector(window, '#extractButton');
        const saveBtn = this.safeQuerySelector(window, '#saveButton');
        const autoModeCheckbox = this.safeQuerySelector(window, '#autoMode');
    // 修改关闭按钮事件处理
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            const floatWindow = document.getElementById('paper-tracker-float');
            const container = document.getElementById('paper-tracker-container');
            if (floatWindow) floatWindow.remove();
            if (container) container.remove();
        });
    }

        if (saveBtn) {
            saveBtn.addEventListener('click', async () => {
                try {
                    const data = this.collectFormData();
                    if (!this.validateFormData(data)) {
                        throw new Error('Please fill in all required fields');
                    }
            
                    // 获取已保存的数据进行重复检查
                    const response = await chrome.runtime.sendMessage({
                        action: 'checkDuplicate',
                        data: {
                            title: data.title,
                            authors: data.authors,
                            year: data.year,
                            publication: data.publication,
                            url: data.url
                        }
                    });
            
                    if (response.isDuplicate) {
                        this.showStatus('This paper information has already been saved!', 'error');
                        return;
                    }
            
                    const saveResponse = await chrome.runtime.sendMessage({
                        action: 'savePaper',
                        data: data
                    });
            
                    if (saveResponse.success) {
                        this.showStatus('Paper saved successfully!', 'success');
                    } else {
                        throw new Error(saveResponse.error || 'Failed to save paper');
                    }
                } catch (error) {
                    console.error('Save failed:', error);
                    this.showStatus('Failed to save paper: ' + error.message, 'error');
                }
            });
        }        
        const statusDiv = window.querySelector('#status');

        // 原有的事件监听器
        minimizeBtn.addEventListener('click', () => {
            window.classList.toggle('minimized');
        });



        extractBtn.addEventListener('click', async () => {
            try {
                // 修改获取 PaperExtractor 的逻辑
                let extractor;
                if (window.PaperExtractor) {
                    extractor = window.PaperExtractor;
                } else if (window.top?.PaperExtractor) {
                    extractor = window.top.PaperExtractor;
                } else {
                    await this.waitForDependencies(); // 等待依赖加载
                    extractor = window.PaperExtractor || window.top?.PaperExtractor;
                }
                
                if (!extractor) {
                    throw new Error('PaperExtractor not available after waiting');
                }
                
                const paperInfo = await new extractor().extractAll();
                if (!paperInfo) {
                    throw new Error('No paper information extracted');
                }
                
                console.log('Extracted paper info:', paperInfo);
                this.fillFormWithData(paperInfo);
                this.showStatus('Information extracted successfully!', 'success');
            } catch (error) {
                console.error('Extraction failed:', error);
                this.showStatus(`Failed to extract information: ${error.message}`, 'error');
            }
        });

        // 加载并同步自动模式状态
        chrome.storage.sync.get(['autoMode'], (result) => {
            autoModeCheckbox.checked = result.autoMode || false;
        });

        autoModeCheckbox.addEventListener('change', (e) => {
            chrome.storage.sync.set({ autoMode: e.target.checked });
        });

        // 新增：初始化标签功能
        this.initTagFeature();
        
        // 新增：初始化笔记功能
        this.initNoteFeature();
    }

    // 新增：标签相关方法
    initTagFeature() {
        const tagInput = document.getElementById('tagInput');
        const addTagBtn = document.getElementById('addTagBtn');
        const categorySelect = document.getElementById('categorySelect');
        const customCategory = document.getElementById('customCategory');

        addTagBtn.addEventListener('click', () => {
            const tagText = tagInput.value.trim();
            if (tagText) {
                this.addTag(tagText);
                tagInput.value = '';
            }
        });

        tagInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const tagText = tagInput.value.trim();
                if (tagText) {
                    this.addTag(tagText);
                    tagInput.value = '';
                }
            }
        });

        categorySelect.addEventListener('change', (e) => {
            if (e.target.value === 'custom') {
                customCategory.classList.remove('hidden');
            } else {
                customCategory.classList.add('hidden');
            }
        });
    }

    addTag(tagText) {
        const tagList = document.getElementById('tagList');
        const tag = document.createElement('div');
        tag.className = 'tag';
        tag.innerHTML = `
            <span>${tagText}</span>
            <span class="tag-remove">×</span>
        `;

        tag.querySelector('.tag-remove').addEventListener('click', () => {
            tag.remove();
        });

        tagList.appendChild(tag);
    }

    // 新增：笔记相关方法
    initNoteFeature() {
        const addNoteBtn = document.getElementById('addNoteBtn');
        
        addNoteBtn.addEventListener('click', () => {
            this.showNoteDialog();
        });
    }

    showNoteDialog(existingNote = null) {
        // 移除已存在的对话框
        const existingDialog = document.querySelector('.note-dialog');
        if (existingDialog) {
            existingDialog.remove();
        }
    
        const dialog = document.createElement('div');
        dialog.className = 'note-dialog';
        dialog.innerHTML = `
            <div class="note-dialog-content">
                <div class="note-dialog-header">
                    <span>Add Note</span>
                    <button class="dialog-close">×</button>
                </div>
                <textarea placeholder="Enter your note...">${existingNote ? existingNote.querySelector('.note-content').textContent : ''}</textarea>
                <div class="note-dialog-actions">
                    <button class="save-note">Save</button>
                    <button class="cancel-note">Cancel</button>
                </div>
            </div>
        `;
    
        // 添加拖拽功能
        const dialogContent = dialog.querySelector('.note-dialog-content');
        const header = dialog.querySelector('.note-dialog-header');
        let isDragging = false;
        let currentX;
        let currentY;
        let initialX;
        let initialY;
    
        header.addEventListener('mousedown', (e) => {
            if (e.target === header || e.target.parentNode === header) {
                isDragging = true;
                initialX = e.clientX - dialogContent.offsetLeft;
                initialY = e.clientY - dialogContent.offsetTop;
                dialogContent.style.transition = 'none';
            }
        });
    
        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            e.preventDefault();
            
            currentX = e.clientX - initialX;
            currentY = e.clientY - initialY;
            
            dialogContent.style.left = `${currentX}px`;
            dialogContent.style.top = `${currentY}px`;
        });
    
        document.addEventListener('mouseup', () => {
            isDragging = false;
            dialogContent.style.transition = 'all 0.2s ease';
        });
    
        // 关闭按钮事件
        dialog.querySelector('.dialog-close').addEventListener('click', () => {
            dialog.remove();
        });
    
        // 取消按钮事件
        dialog.querySelector('.cancel-note').addEventListener('click', () => {
            dialog.remove();
        });
    
        // 保存按钮事件
        dialog.querySelector('.save-note').addEventListener('click', () => {
            const noteText = dialog.querySelector('textarea').value.trim();
            if (noteText) {
                if (existingNote) {
                    existingNote.querySelector('.note-content').textContent = noteText;
                } else {
                    this.addNote(noteText);
                }
            }
            dialog.remove();
        });
    
        document.body.appendChild(dialog);
        dialog.querySelector('textarea').focus();
    }

    addNote(noteText) {
        const notesList = document.getElementById('notesList');
        const note = document.createElement('div');
        note.className = 'note-item';
        
        const date = new Date().toLocaleString();
        note.innerHTML = `
            <div class="note-header">
                <span>${date}</span>
                <div class="note-actions">
                    <span class="note-edit">Edit</span>
                    <span class="note-delete">Delete</span>
                </div>
            </div>
            <div class="note-content">${noteText}</div>
        `;

        note.querySelector('.note-delete').addEventListener('click', () => {
            note.remove();
        });

        note.querySelector('.note-edit').addEventListener('click', () => {
            this.showNoteDialog(note);
        });

        notesList.appendChild(note);
    }

    showStatus(message, type = 'success') {
        if (!message) {
            console.warn('No message provided for status');
            return;
        }
    
        const window = document.getElementById('paper-tracker-float');
        const statusDiv = window ? this.safeQuerySelector(window, '#status') : null;
        if (!statusDiv) {
            console.warn('Status div not found');
            return;
        }
        
        statusDiv.textContent = message;
        statusDiv.className = `status ${type}`;
        statusDiv.style.opacity = '1';
        
        setTimeout(() => {
            if (statusDiv && document.contains(statusDiv)) {
                statusDiv.style.opacity = '0';
            }
        }, 3000);
    }

    // 修改：更新表单数据填充方法
    fillFormWithData(data) {
        console.log('Filling form with data:', data);
        console.log('Using form fields:', this.formFields);

        // 填充基本字段
        Object.keys(this.formFields).forEach(key => {
            const element = document.getElementById(this.formFields[key]);
            if (element && data[key]) {
                element.value = data[key];
            }
        });

        // 填充标签
        if (Array.isArray(data.tags)) {
            data.tags.forEach(tag => this.addTag(tag));
        }

        // 填充分类
        const categorySelect = document.getElementById('categorySelect');
        const customCategory = document.getElementById('customCategory');
        if (categorySelect && data.category) {
            categorySelect.value = data.category;
            if (data.category === 'custom' && customCategory) {
                customCategory.classList.remove('hidden');
                customCategory.value = data.customCategory || '';
            }
        }

        // 填充笔记
        if (Array.isArray(data.notes)) {
            data.notes.forEach(note => {
                if (typeof note === 'object' && note.text) {
                    this.addNote(note.text);
                }
            });
        }
    }

    // 添加新的辅助方法用于验证数据
    validateFormData(data) {
        if (!data) return false;
        
        // 只检查标题是否存在
        if (!data.title || data.title.trim() === '') {
            console.warn('Missing required field: title');
            return false;
        }
        
        return true;
    }


    // 修改：更新表单数据收集方法
    collectFormData() {
        // 使用实例的 formFields
        const data = {
            title: document.getElementById(this.formFields.title)?.value || '',
            authors: document.getElementById(this.formFields.authors)?.value || '',
            year: document.getElementById(this.formFields.year)?.value || '',
            publication: document.getElementById(this.formFields.publication)?.value || '',
            abstract: document.getElementById(this.formFields.abstract)?.value || '',
            url: document.getElementById(this.formFields.url)?.value || '',
            
            // 标签收集
            tags: Array.from(document.querySelectorAll('.tag')).map(tag => 
                tag.querySelector('span')?.textContent || ''
            ).filter(tag => tag !== ''),
            
            // 分类收集
            category: document.getElementById('categorySelect')?.value || '',
            customCategory: document.getElementById('customCategory')?.value || '',
            
            // 笔记收集
            notes: Array.from(document.querySelectorAll('.note-item')).map(note => ({
                text: note.querySelector('.note-content')?.textContent || '',
                date: note.querySelector('.note-header span')?.textContent || ''
            }))
        };

        console.log('Collected form data:', data);
        return data;
    }

    initDragFeature() {
        // 原有的拖拽功能代码保持不变
        const window = document.getElementById('paper-tracker-float');
        if (!window) {
            console.warn('Window element not found for drag feature');
            return;
        }
        
        const header = window.querySelector('.paper-tracker-header');
        if (!header) {
            console.warn('Header element not found for drag feature');
            return;
        }
        let isDragging = false;
        let currentX;
        let currentY;
        let initialX;
        let initialY;
    
        header.addEventListener('mousedown', (e) => {
            isDragging = true;
            window.style.transition = 'none';
            
            initialX = e.clientX - window.offsetLeft;
            initialY = e.clientY - window.offsetTop;
        });
    
        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
    
            e.preventDefault();
            
            currentX = e.clientX - initialX;
            currentY = e.clientY - initialY;
    
            // 防止拖出视口
            currentX = Math.max(0, Math.min(currentX, document.documentElement.clientWidth - window.offsetWidth));
            currentY = Math.max(0, Math.min(currentY, document.documentElement.clientHeight - window.offsetHeight));
    
            window.style.left = `${currentX}px`;
            window.style.top = `${currentY}px`;
        });
    
        document.addEventListener('mouseup', () => {
            isDragging = false;
            window.style.transition = 'all 0.2s ease';
        });        
    }
}


// 正确导出和设置全局变量
if (typeof window !== 'undefined') {
    window.FloatingWindow = FloatingWindow;
    console.log('FloatingWindow class registered globally');
}

// 如果在 iframe 中，也尝试设置到顶层窗口
if (window !== window.top) {
    try {
        window.top.FloatingWindow = FloatingWindow;
        console.log('FloatingWindow class registered in top window');
    } catch (e) {
        console.warn('Unable to set FloatingWindow in top window:', e);
    }
}

// 修改自动初始化逻辑
async function initializeFloatingWindow() {
    try {
        // 等待 DOM 加载完成
        if (document.readyState !== 'complete') {
            await new Promise(resolve => window.addEventListener('load', resolve));
        }

        // 等待 PaperExtractor 加载
        await waitForPaperExtractor();

        // 确保只初始化一次
        if (!window.floatingWindowInstance) {
            window.floatingWindowInstance = new FloatingWindow();
            await window.floatingWindowInstance.initializeAsync();
            console.log('FloatingWindow initialized for PDF page');
        }
    } catch (error) {
        console.error('Failed to initialize FloatingWindow:', error);
    }
}

// 对于 PDF 页面，延迟初始化以确保所有依赖都加载完成
if (window.location.pathname.includes('/pdf/')) {
    setTimeout(initializeFloatingWindow, 1000);
}