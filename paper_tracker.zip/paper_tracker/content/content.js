// content.js
window.BaseExtractor = class BaseExtractor {
    constructor() {
        this.metaSelectors = {
            title: [
                'meta[name="citation_title"]',
                'meta[property="og:title"]',
                'meta[name="dc.title"]'
            ],
            authors: [
                'meta[name="citation_author"]',
                'meta[name="author"]',
                'meta[name="dc.creator"]'
            ],
            year: [
                'meta[name="citation_publication_date"]',
                'meta[name="citation_date"]',
                'meta[name="dc.date"]'
            ],
            abstract: [
                'meta[name="description"]',
                'meta[name="citation_abstract"]',
                'meta[property="og:description"]'
            ],
            publication: [
                'meta[name="citation_journal_title"]',
                'meta[name="citation_conference"]',
                'meta[name="citation_conference_title"]',
                'meta[name="prism.publicationName"]',
                'meta[name="citation_inbook_title"]'
            ]
        };
    }

    // 基础元数据提取方法
    extractMetaContent(selectors) {
        for (const selector of selectors) {
            const element = document.querySelector(selector);
            if (element && element.content) {
                return element.content.trim();
            }
        }
        return '';
    }


    // 从元素中提取文本
    extractTextContent(selector) {
        const element = document.querySelector(selector);
        return element ? element.textContent.trim() : '';
    }

    // Schema.org 数据提取
    extractSchemaData() {
        const schemaScript = document.querySelector('script[type="application/ld+json"]');
        if (schemaScript) {
            try {
                return JSON.parse(schemaScript.textContent);
            } catch (e) {
                console.error('Error parsing Schema.org data:', e);
            }
        }
        return null;
    }

    // 主要提取方法
    async extract() {
        return {
            title: this.extractTitle(),
            authors: this.extractAuthors(),
            year: this.extractYear(),
            abstract: this.extractAbstract(),
            Publication: this.extractPublication(),
            url: window.location.href
        };
    }

    // 各字段的提取方法
    extractTitle() {
        return this.extractMetaContent(this.metaSelectors.title);
    }

    extractAuthors() {
        return this.extractMetaContent(this.metaSelectors.authors);
    }

    extractYear() {
        const dateStr = this.extractMetaContent(this.metaSelectors.year);
        return dateStr ? dateStr.match(/\d{4}/)?.[0] || '' : '';
    }

    extractAbstract() {
        return this.extractMetaContent(this.metaSelectors.abstract);
    }

    extractPublication() {
        return this.extractMetaContent(this.metaSelectors.publication);
    }
}


window.PaperExtractor = class PaperExtractor extends window.BaseExtractor {
    constructor() {
        super();
    }  
    // 获取默认列设置
    async getActiveColumns() {
        const DEFAULT_SETTINGS = {
            columns: [
                { id: 'title', name: 'Title', enabled: true },
                { id: 'authors', name: 'Authors', enabled: true },
                { id: 'year', name: 'Year', enabled: true },
                { id: 'publication', name: 'Publication', enabled: true }, 
                { id: 'abstract', name: 'Abstract', enabled: true },
                { id: 'url', name: 'URL', enabled: true },
                { id: 'tags', name: 'Tags', enabled: true },
                { id: 'category', name: 'Category', enabled: true },
                { id: 'customCategory', name: 'Custom Category', enabled: true },
                { id: 'notes', name: 'Notes', enabled: true },
                { id: 'dateAdded', name: 'Date Added', enabled: true }
            ]
        };

        return new Promise((resolve) => {
            chrome.storage.sync.get(DEFAULT_SETTINGS, (settings) => {
                resolve(settings.columns || DEFAULT_SETTINGS.columns);
            });
        });
    }

    // 保持原有的提取方法不变
    extractTitle() {
        let title = '';
        const hostname = window.location.hostname;

        // arXiv
        if (hostname.includes('arxiv.org')) {
            title = document.querySelector('h1.title') ? document.querySelector('h1.title').textContent.replace('Title:', '').trim() : '';
        }
        // IEEE
        else if (hostname.includes('ieee.org')) {
            title = document.querySelector('h1.document-title') ? document.querySelector('h1.document-title').textContent.trim() : '';
        }
        // ACM
        else if (hostname.includes('acm.org')) {
            title = document.querySelector('h1.citation__title') ? document.querySelector('h1.citation__title').textContent.trim() : '';
        }
        // ScienceDirect
        else if (hostname.includes('sciencedirect.com')) {
            title = document.querySelector('.title-text') ? document.querySelector('.title-text').textContent.trim() : '';
        }
        // Springer
        else if (hostname.includes('springer.com')) {
            title = document.querySelector('h1.c-article-title') ? document.querySelector('h1.c-article-title').textContent.trim() : '';
        }
        // Nature
        else if (hostname.includes('nature.com')) {
            title = document.querySelector('h1.c-article-title') ? document.querySelector('h1.c-article-title').textContent.trim() : '';
        }
        // Science
        else if (hostname.includes('science.org')) {
            title = document.querySelector('h1.article__headline') ? document.querySelector('h1.article__headline').textContent.trim() : '';
        }
        // JSTOR
        else if (hostname.includes('jstor.org')) {
            title = document.querySelector('.title-container h1') ? document.querySelector('.title-container h1').textContent.trim() : '';
        }
        // ResearchGate
        else if (hostname.includes('researchgate.net')) {
            title = document.querySelector('h1.research-detail-header-section__title') ? 
                   document.querySelector('h1.research-detail-header-section__title').textContent.trim() : '';
        }
        // Wiley Online Library
        else if (hostname.includes('wiley.com')) {
            title = document.querySelector('h1.citation__title') ? document.querySelector('h1.citation__title').textContent.trim() : '';
        }
        // MDPI
        else if (hostname.includes('mdpi.com')) {
            title = document.querySelector('h1.title') ? document.querySelector('h1.title').textContent.trim() : '';
        }

        // Default: try common selectors
        if (!title) {
            const possibleTitleElements = [
                document.querySelector('h1'),
                document.querySelector('meta[property="og:title"]'),
                document.querySelector('meta[name="citation_title"]'),
                document.querySelector('meta[name="dc.title"]')
            ];

            for (const element of possibleTitleElements) {
                if (element) {
                    title = element.content || element.textContent;
                    break;
                }
            }
        }
        return title.trim();
    }

    extractAuthors() {
        let authors = '';
        const hostname = window.location.hostname;

        // arXiv
        if (hostname.includes('arxiv.org')) {
            authors = document.querySelector('.authors') ? document.querySelector('.authors').textContent.replace('Authors:', '').trim() : '';
        }
        // IEEE
        else if (hostname.includes('ieee.org')) {
            const authorElements = document.querySelectorAll('span.authors-info-name');
            authors = Array.from(authorElements).map(el => el.textContent.trim()).join(', ');
        }
        // ACM
        else if (hostname.includes('acm.org')) {
            const authorElements = document.querySelectorAll('span.loa__author-name');
            authors = Array.from(authorElements).map(el => el.textContent.trim()).join(', ');
        }
        // ScienceDirect
        else if (hostname.includes('sciencedirect.com')) {
            const authorElements = document.querySelectorAll('.author-group .content span.text');
            authors = Array.from(authorElements).map(el => el.textContent.trim()).join(', ');
        }
        // Springer
        else if (hostname.includes('springer.com')) {
            const authorElements = document.querySelectorAll('a.c-article-author-link');
            authors = Array.from(authorElements).map(el => el.textContent.trim()).join(', ');
        }
        // Nature
        else if (hostname.includes('nature.com')) {
            const authorElements = document.querySelectorAll('ul.c-article-author-list li');
            authors = Array.from(authorElements).map(el => el.textContent.trim()).join(', ');
        }
        // Science
        else if (hostname.includes('science.org')) {
            const authorElements = document.querySelectorAll('.article__author-list .article-author-list__name');
            authors = Array.from(authorElements).map(el => el.textContent.trim()).join(', ');
        }
        // JSTOR
        else if (hostname.includes('jstor.org')) {
            const authorElements = document.querySelectorAll('.author-name');
            authors = Array.from(authorElements).map(el => el.textContent.trim()).join(', ');
        }
        // ResearchGate
        else if (hostname.includes('researchgate.net')) {
            const authorElements = document.querySelectorAll('.research-detail-header-section__author-list a');
            authors = Array.from(authorElements).map(el => el.textContent.trim()).join(', ');
        }
        // Wiley Online Library
        else if (hostname.includes('wiley.com')) {
            const authorElements = document.querySelectorAll('.article-header__authors-list a');
            authors = Array.from(authorElements).map(el => el.textContent.trim()).join(', ');
        }
        // MDPI
        else if (hostname.includes('mdpi.com')) {
            const authorElements = document.querySelectorAll('.art-authors .author');
            authors = Array.from(authorElements).map(el => el.textContent.trim()).join(', ');
        }

        // Default: try common selectors
        if (!authors) {
            const possibleAuthorElements = [
                document.querySelectorAll('meta[name="citation_author"]'),
                document.querySelectorAll('meta[name="author"]'),
                document.querySelectorAll('meta[name="dc.creator"]')
            ];

            for (const elements of possibleAuthorElements) {
                if (elements.length > 0) {
                    authors = Array.from(elements).map(el => el.content).join(', ');
                    break;
                }
            }
        }
        return authors.trim();
    }

    extractYear() {
        let year = '';
        const hostname = window.location.hostname;

        // 尝试从 URL 中获取年份（通常用于 arXiv）
        const yearMatch = window.location.href.match(/\d{4}/);
        if (yearMatch) {
            year = yearMatch[0];
        }

        // 如果 URL 中没有年份，尝试从页面元素获取
        if (!year) {
            let dateElement = null;

            // arXiv
            if (hostname.includes('arxiv.org')) {
                dateElement = document.querySelector('.dateline');
            }
            // IEEE
            else if (hostname.includes('ieee.org')) {
                dateElement = document.querySelector('.article-date');
            }
            // ScienceDirect
            else if (hostname.includes('sciencedirect.com')) {
                dateElement = document.querySelector('.publication-volume-info');
            }
            // Springer
            else if (hostname.includes('springer.com')) {
                dateElement = document.querySelector('.c-article-info-details time');
            }
            // Nature
            else if (hostname.includes('nature.com')) {
                dateElement = document.querySelector('.c-article-info-details time');
            }
            // Others: try common date selectors
            if (!year && dateElement) {
                const dateMatch = dateElement.textContent.match(/\d{4}/);
                if (dateMatch) {
                    year = dateMatch[0];
                }
            }
        }

        // 如果还没找到年份，尝试meta标签
        if (!year) {
            const dateSelectors = [
                'meta[name="citation_publication_date"]',
                'meta[name="citation_date"]',
                'meta[name="publication_date"]',
                'meta[name="prism.publicationDate"]',
                'meta[name="dc.date"]',
                'meta[name="date"]'
            ];

            for (const selector of dateSelectors) {
                const element = document.querySelector(selector);
                if (element) {
                    const dateMatch = element.content.match(/\d{4}/);
                    if (dateMatch) {
                        year = dateMatch[0];
                        break;
                    }
                }
            }
        }

        return year;
    }

    extractPublication() {
        let publication = '';
        const hostname = window.location.hostname;
    
        // 尝试从meta标签获取出版物信息
        const publicationSelectors = [
            'meta[name="citation_journal_title"]',
            'meta[name="citation_conference"]',
            'meta[name="citation_conference_title"]',
            'meta[name="citation_publication"]',
            'meta[name="prism.publicationName"]',
            'meta[name="citation_inbook_title"]'
        ];
    
        for (const selector of publicationSelectors) {
            const element = document.querySelector(selector);
            if (element) {
                publication = element.content;
                break;
            }
        }
    
        // 如果meta标签没有出版物信息，尝试从页面内容获取
        if (!publication) {
            // arXiv
            if (hostname.includes('arxiv.org')) {
                const comments = document.querySelector('.comments');
                if (comments) {
                    publication = comments.textContent.trim();
                }
                // 如果没有comments，使用arXiv分类
                if (!publication) {
                    const category = document.querySelector('.primary-subject');
                    if (category) {
                        publication = `arXiv: ${category.textContent.trim()}`;
                    }
                }
            }
            // IEEE
            else if (hostname.includes('ieee.org')) {
                const confElement = document.querySelector('.publisher-conference-info');
                if (confElement) {
                    publication = confElement.textContent.trim();
                }
                // 尝试获取期刊信息
                if (!publication) {
                    const journalElement = document.querySelector('.publisher-journal-info');
                    if (journalElement) {
                        publication = journalElement.textContent.trim();
                    }
                }
            }
            // ACM
            else if (hostname.includes('acm.org')) {
                const confElement = document.querySelector('.conference-info');
                if (confElement) {
                    publication = confElement.textContent.trim();
                }
                // 尝试获取期刊信息
                if (!publication) {
                    const journalElement = document.querySelector('.journal-info');
                    if (journalElement) {
                        publication = journalElement.textContent.trim();
                    }
                }
            }
            // ScienceDirect
            else if (hostname.includes('sciencedirect.com')) {
                const pubElement = document.querySelector('.publication-title-link');
                if (pubElement) {
                    publication = pubElement.textContent.trim();
                }
            }
            // Springer
            else if (hostname.includes('springer.com')) {
                const pubElement = document.querySelector('.c-article-info-details .c-article-info-details__item');
                if (pubElement) {
                    publication = pubElement.textContent.trim();
                }
            }
            // Nature
            else if (hostname.includes('nature.com')) {
                const pubElement = document.querySelector('.c-journal-title');
                if (pubElement) {
                    publication = pubElement.textContent.trim();
                }
            }
            // Science
            else if (hostname.includes('science.org')) {
                const pubElement = document.querySelector('.journal-info');
                if (pubElement) {
                    publication = pubElement.textContent.trim();
                }
            }
            // JSTOR
            else if (hostname.includes('jstor.org')) {
                const pubElement = document.querySelector('.journal-title');
                if (pubElement) {
                    publication = pubElement.textContent.trim();
                }
            }
            // ResearchGate
            else if (hostname.includes('researchgate.net')) {
                const pubElement = document.querySelector('.research-detail-header-section__source');
                if (pubElement) {
                    publication = pubElement.textContent.trim();
                }
            }
            // Wiley
            else if (hostname.includes('wiley.com')) {
                const pubElement = document.querySelector('.citation__journal-title');
                if (pubElement) {
                    publication = pubElement.textContent.trim();
                }
            }
            // MDPI
            else if (hostname.includes('mdpi.com')) {
                const pubElement = document.querySelector('.journal-title');
                if (pubElement) {
                    publication = pubElement.textContent.trim();
                }
            }
        }
    
        return publication.trim();
    }




    extractAbstract() {
        let abstract = '';
        const hostname = window.location.hostname;

        // arXiv
        if (hostname.includes('arxiv.org')) {
            abstract = document.querySelector('.abstract') ? document.querySelector('.abstract').textContent.replace('Abstract:', '').trim() : '';
        }
        // IEEE
        else if (hostname.includes('ieee.org')) {
            abstract = document.querySelector('.abstract-text') ? document.querySelector('.abstract-text').textContent.trim() : '';
        }
        // ACM
        else if (hostname.includes('acm.org')) {
            abstract = document.querySelector('.abstractInFull') ? document.querySelector('.abstractInFull').textContent.trim() : '';
        }
        // ScienceDirect
        else if (hostname.includes('sciencedirect.com')) {
            abstract = document.querySelector('.abstract.author') ? document.querySelector('.abstract.author').textContent.trim() : '';
        }
        // Springer
        else if (hostname.includes('springer.com')) {
            abstract = document.querySelector('div[id="Abs1-content"]') ? document.querySelector('div[id="Abs1-content"]').textContent.trim() : '';
        }
        // Nature
        else if (hostname.includes('nature.com')) {
            abstract = document.querySelector('.c-article-section__content') ? document.querySelector('.c-article-section__content').textContent.trim() : '';
        }
        // Science
        else if (hostname.includes('science.org')) {
            abstract = document.querySelector('.section-paragraph') ? document.querySelector('.section-paragraph').textContent.trim() : '';
        }
        // JSTOR
        else if (hostname.includes('jstor.org')) {
            abstract = document.querySelector('.abstract') ? document.querySelector('.abstract').textContent.trim() : '';
        }
        // ResearchGate
        else if (hostname.includes('researchgate.net')) {
            abstract = document.querySelector('.research-detail-header-section__abstract') ? 
                      document.querySelector('.research-detail-header-section__abstract').textContent.trim() : '';
        }
        // Wiley Online Library
        else if (hostname.includes('wiley.com')) {
            abstract = document.querySelector('.article-section__content') ? document.querySelector('.article-section__content').textContent.trim() : '';
        }
        // MDPI
        else if (hostname.includes('mdpi.com')) {
            abstract = document.querySelector('.art-abstract') ? document.querySelector('.art-abstract').textContent.trim() : '';
        }

        // Default: try common selectors
        if (!abstract) {
            const possibleAbstractElements = [
                document.querySelector('meta[name="description"]'),
                document.querySelector('meta[name="citation_abstract"]'),
                document.querySelector('meta[name="dc.description"]'),
                document.querySelector('[property="og:description"]')
            ];

            for (const element of possibleAbstractElements) {
                if (element) {
                    abstract = element.content;
                    break;
                }
            }
        }
        return abstract.trim();
    }

    // 新增其他字段的提取方法
    extractTags() {
        // 默认返回空数组，因为标签通常需要用户手动添加
        return [];
    }

    extractCategory() {
        // 可以根据标题或内容尝试推断类别
        return '';
    }

    extractCustomCategory() {
        return '';
    }

    extractNotes() {
        return [];
    }

    // 添加新方法：检查是否为 arXiv PDF 页面
    isArxivPDF() {
        return window.location.href.includes('arxiv.org/pdf/');
    }

    // 添加新方法：从 PDF URL 中提取 arXiv ID
    getArxivIdFromUrl() {
        const match = window.location.href.match(/arxiv\.org\/pdf\/(\d+\.\d+)/);
        return match ? match[1] : null;
    }

    // 添加新方法：通过 API 获取 arXiv 论文信息
    async getArxivApiInfo() {
        const arxivId = this.getArxivIdFromUrl();
        if (!arxivId) return null;

        try {
            const apiUrl = `https://export.arxiv.org/api/query?id_list=${arxivId}`;
            const response = await fetch(apiUrl);
            const text = await response.text();
            
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(text, "text/xml");
            
            const entry = xmlDoc.querySelector('entry');
            if (!entry) return null;

            return {
                title: entry.querySelector('title')?.textContent?.trim(),
                authors: Array.from(entry.querySelectorAll('author name'))
                    .map(author => author.textContent.trim())
                    .join(', '),
                abstract: entry.querySelector('summary')?.textContent?.trim(),
                year: entry.querySelector('published')?.textContent?.substring(0, 4),
                category: Array.from(entry.querySelectorAll('category'))
                    .map(cat => cat.getAttribute('term'))
                    .join(', '),
                publication: 'arXiv'
            };
        } catch (error) {
            console.error('Error fetching arXiv API:', error);
            return null;
        }
    }   
    
    // 修改提取所有信息的方法
    async extractAll() {
        try {
            const activeColumns = await this.getActiveColumns();
            const result = {};
    
            // 检查是否为 arXiv PDF 页面并获取 API 数据
            if (this.isArxivPDF()) {
                console.log('PDF page detected, using arXiv API');
                const apiInfo = await this.getArxivApiInfo();
                
                if (apiInfo) {
                    console.log('Successfully retrieved data from arXiv API');
                    // 填充从 API 获取的信息
                    for (const column of activeColumns) {
                        if (column.enabled) {
                            switch (column.id) {
                                case 'title':
                                    result.title = apiInfo.title || '';
                                    break;
                                case 'authors':
                                    result.authors = apiInfo.authors || '';
                                    break;
                                case 'year':
                                    result.year = apiInfo.year || '';
                                    break;
                                case 'publication':
                                    result.publication = apiInfo.publication || '';
                                    break;
                                case 'abstract':
                                    result.abstract = apiInfo.abstract || '';
                                    break;
                                case 'url':
                                    result.url = window.location.href.replace('/pdf/', '/abs/');
                                    break;
                                case 'category':
                                    result.category = apiInfo.category || '';
                                    break;
                                case 'tags':
                                    result.tags = this.extractTags();
                                    break;
                                case 'customCategory':
                                    result.customCategory = this.extractCustomCategory();
                                    break;
                                case 'notes':
                                    result.notes = this.extractNotes();
                                    break;
                                case 'dateAdded':
                                    result.dateAdded = new Date().toISOString().split('T')[0];
                                    break;
                            }
                        }
                    }
                    return result;
                }
                console.log('Failed to get data from arXiv API, falling back to default extraction');
            }
    
            // 常规页面提取
            for (const column of activeColumns) {
                if (column.enabled) {
                    switch (column.id) {
                        case 'title':
                            result.title = this.extractTitle() || '';
                            break;
                        case 'authors':
                            result.authors = this.extractAuthors() || '';
                            break;
                        case 'year':
                            result.year = this.extractYear() || '';
                            break;
                        case 'publication':
                            result.publication = this.extractPublication() || '';
                            break;
                        case 'abstract':
                            result.abstract = this.extractAbstract() || '';
                            break;
                        case 'url':
                            result.url = window.location.href;
                            break;
                        case 'tags':
                            result.tags = this.extractTags();
                            break;
                        case 'category':
                            result.category = this.extractCategory() || '';
                            break;
                        case 'customCategory':
                            result.customCategory = this.extractCustomCategory() || '';
                            break;
                        case 'notes':
                            result.notes = this.extractNotes();
                            break;
                        case 'dateAdded':
                            result.dateAdded = new Date().toISOString().split('T')[0];
                            break;
                    }
                }
            }
    
            console.log('Extracted data:', result);
            return result;
        } catch (error) {
            console.error('Error in extractAll:', error);
            throw error;
        }
    }
}    

// 在文件顶部添加检查
if (!window.FloatingWindow) {
    console.error('FloatingWindow class not found. Make sure floatingWindow.js is loaded first.');
}

// 添加等待函数
async function waitForFloatingWindow(timeout = 5000) {
    const startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
        try {
            // 检查当前窗口中的 FloatingWindow
            if (window.FloatingWindow) {
                console.log('Found FloatingWindow in current window');
                return window.FloatingWindow;
            }
            
            // 检查顶层窗口中的 FloatingWindow
            if (window !== window.top && window.top?.FloatingWindow) {
                console.log('Found FloatingWindow in top window');
                return window.top.FloatingWindow;
            }
        } catch (e) {
            console.warn('Error checking for FloatingWindow:', e);
        }
        
        await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    throw new Error('FloatingWindow class not available after timeout');
}

// 修改 toggleFloatingWindow 函数
async function toggleFloatingWindow(data) {
    try {
        console.log('Attempting to toggle floating window with data:', data);
        
        // 检查是否已存在悬浮窗
        const existingWindow = document.getElementById('paper-tracker-float');
        if (existingWindow) {
            console.log('Removing existing window');
            existingWindow.remove();
            return;
        }

        // 等待 FloatingWindow 类加载
        const FloatingWindowClass = await waitForFloatingWindow();
        if (!FloatingWindowClass) {
            throw new Error('FloatingWindow class not available');
        }

        console.log('Creating new floating window');
        const floatingWindow = new FloatingWindowClass(data);
        await floatingWindow.initializeAsync(); // 确保等待初始化完成
        console.log('Floating window instance created and initialized');
    } catch (error) {
        console.error('Error toggling floating window:', error);
        console.error('Error stack:', error.stack);
        throw error;
    }
}

// 添加重新加载 FloatingWindow 的函数
async function reloadFloatingWindow() {
    try {
        const script = document.createElement('script');
        script.src = chrome.runtime.getURL('content/floatingWindow.js');
        document.head.appendChild(script);
        
        // 等待脚本加载完成
        await new Promise((resolve, reject) => {
            script.onload = resolve;
            script.onerror = reject;
        });
        
        console.log('Reloaded FloatingWindow script');
    } catch (error) {
        console.error('Failed to reload FloatingWindow:', error);
    }
}

// 检查是否在 iframe 中
function isInIframe() {
    try {
      return window !== window.top;
    } catch (e) {
      return true;
    }
  }
  
// 根据环境调整消息传递
if (isInIframe()) {
    try {
        console.log('Setting up iframe message handling');
        window.top.postMessage({ type: 'FROM_IFRAME', action: 'ready' }, '*');
        
        window.addEventListener('message', async (event) => {
            console.log('Iframe received message:', event.data);
            if (event.data && event.data.action === 'createFloatingWindow') {
                try {
                    console.log('Received createFloatingWindow message with data:', event.data.data);
                    await toggleFloatingWindow(event.data.data);
                } catch (error) {
                    console.error('Error handling iframe message:', error);
                }
            }
        });
    } catch (error) {
        console.error('Error in iframe message handling:', error);
    }
}



// 添加处理 iframe 消息的函数
function handleIframeMessage(data) {
    switch (data.action) {
      case 'ready':
        // 初始化处理
        console.log('iframe ready');
        break;
      case 'getPaperInfo':
        // 处理获取论文信息的请求
        extractPaperInfo();
        break;
      // 添加其他消息处理...
    }
  }  

// 提取论文信息的函数
async function extractPaperInfo() {
    try {
      const info = {
        title: '',
        authors: [],
        abstract: '',
        pdf_url: '',
        categories: [],
        date: '',
        isPDF: false
      };
  
      if (isInIframe()) {
        // PDF 页面特定的提取逻辑
        info.isPDF = true;
        info.pdf_url = window.location.href;
        
        // 从 URL 中提取论文 ID
        const match = window.location.pathname.match(/\/pdf\/([^\/]+)/);
        if (match) {
          info.id = match[1];
        }
  
        // 发送信息到顶层窗口
        window.top.postMessage({
          type: 'FROM_IFRAME',
          action: 'paperInfo',
          data: info
        }, '*');
      } else {
        // arXiv 摘要页面的提取逻辑
        // 标题
        const titleElement = document.querySelector('h1.title');
        info.title = titleElement ? titleElement.textContent.replace('Title:', '').trim() : '';
  
        // 作者
        const authorElement = document.querySelector('.authors');
        if (authorElement) {
          info.authors = Array.from(authorElement.querySelectorAll('a'))
            .map(a => a.textContent.trim())
            .filter(author => author.length > 0);
        }
  
        // 摘要
        const abstractElement = document.querySelector('.abstract');
        info.abstract = abstractElement ? 
          abstractElement.textContent.replace('Abstract:', '').trim() : '';
  
        // PDF URL
        const pdfLink = document.querySelector('a[href*="/pdf/"]');
        info.pdf_url = pdfLink ? pdfLink.href : '';
  
        // 分类
        const subjectsElement = document.querySelector('.subjects');
        if (subjectsElement) {
          info.categories = Array.from(subjectsElement.querySelectorAll('span'))
            .map(span => span.textContent.trim())
            .filter(category => category.length > 0);
        }
  
        // 日期
        const dateElement = document.querySelector('.submission-history');
        if (dateElement) {
          const dateMatch = dateElement.textContent.match(/\[v1\] (.+?)(?:\s|$)/);
          info.date = dateMatch ? dateMatch[1].trim() : '';
        }
  
        // 论文 ID
        const match = window.location.pathname.match(/\/abs\/([^\/]+)/);
        if (match) {
          info.id = match[1];
        }
      }
  
      // 清理数据中的多余空白字符
      Object.keys(info).forEach(key => {
        if (typeof info[key] === 'string') {
          info[key] = info[key].replace(/\s+/g, ' ').trim();
        }
      });
  
      return info;
    } catch (error) {
      console.error('Error extracting paper info:', error);
      throw error;
    }
  }


// 添加辅助函数以检查和获取 PaperExtractor
async function getPaperExtractor() {
    // 等待最多 2 秒
    for (let i = 0; i < 20; i++) {
        // 先检查当前窗口
        if (window.PaperExtractor) {
            return window.PaperExtractor;
        }
        // 再检查顶层窗口
        if (window.top?.PaperExtractor) {
            return window.top.PaperExtractor;
        }
        // 等待 100ms
        await new Promise(resolve => setTimeout(resolve, 100));
    }
    throw new Error('PaperExtractor not available after waiting');
}

// 修改消息监听器
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('Content script received message:', message, {
        location: window.location.href,
        isPDF: window.location.pathname.includes('/pdf/'),
        hasPaperExtractor: !!window.PaperExtractor,
        hasTopPaperExtractor: !!window.top?.PaperExtractor
    });

    // 使用 async IIFE 处理异步操作
    (async () => {
        try {
            switch (message.action) {
                case 'getPaperInfo':
                case 'extractInfo':
                    try {
                        const PaperExtractor = await getPaperExtractor();
                        const extractor = new PaperExtractor();
                        const info = await extractor.extractAll();
                        console.log('Successfully extracted paper info:', info);
                        sendResponse({ success: true, data: info });
                    } catch (error) {
                        console.error('Extraction error:', error);
                        sendResponse({ 
                            success: false, 
                            error: `Failed to extract paper info: ${error.message}` 
                        });
                    }
                    break;

                case 'createFloatingWindow':
                case 'toggleFloatingWindow':
                    try {
                        // 如果是 PDF 页面，先尝试提取信息
                        let data = message.data;
                        if (window.location.pathname.includes('/pdf/') && !data) {
                            const PaperExtractor = await getPaperExtractor();
                            const extractor = new PaperExtractor();
                            data = await extractor.extractAll();
                        }

                        await toggleFloatingWindow(data);
                        console.log('Successfully created/toggled floating window');
                        sendResponse({ success: true });
                    } catch (error) {
                        console.error('Floating window error:', error);
                        sendResponse({ 
                            success: false, 
                            error: `Failed to handle floating window: ${error.message}` 
                        });
                    }
                    break;

                default:
                    console.warn('Unknown message action:', message.action);
                    sendResponse({ 
                        success: false, 
                        error: 'Unknown action' 
                    });
            }
        } catch (error) {
            console.error('Message handling error:', error);
            sendResponse({ 
                success: false, 
                error: `Message handling failed: ${error.message}` 
            });
        }
    })();

    // 保持消息通道开放
    return true;
});


// 当在 iframe 中时，设置与父窗口的通信
if (window !== window.top) {
    window.addEventListener('message', async (event) => {
        if (event.data && event.data.type === 'FROM_PARENT') {
            console.log('Received message from parent:', event.data);
            try {
                switch (event.data.action) {
                    case 'extractInfo':
                        const PaperExtractor = await getPaperExtractor();
                        const extractor = new PaperExtractor();
                        const info = await extractor.extractAll();
                        window.top.postMessage({
                            type: 'FROM_IFRAME',
                            action: 'extractInfo',
                            data: info,
                            success: true
                        }, '*');
                        break;

                    case 'createFloatingWindow':
                        await toggleFloatingWindow(event.data.data);
                        window.top.postMessage({
                            type: 'FROM_IFRAME',
                            action: 'createFloatingWindow',
                            success: true
                        }, '*');
                        break;
                }
            } catch (error) {
                console.error('Error handling parent message:', error);
                window.top.postMessage({
                    type: 'FROM_IFRAME',
                    action: event.data.action,
                    success: false,
                    error: error.message
                }, '*');
            }
        }
    });
}

// 添加调试日志
console.log('Content.js loaded', {
    baseExtractor: !!(window.BaseExtractor || window.top?.BaseExtractor),
    paperExtractor: !!(window.PaperExtractor || window.top?.PaperExtractor),
    floatingWindow: !!(window.FloatingWindow || window.top?.FloatingWindow),
    isIframe: window !== window.top,
    windowContext: {
        location: window.location.href,
        top: window.top !== window,
        parent: window.parent !== window
    }
});

// 替换为一次性检查
window.addEventListener('load', () => {
    console.log('Initial dependencies status:', {
        baseExtractor: !!(window.BaseExtractor || window.top?.BaseExtractor),
        paperExtractor: !!(window.PaperExtractor || window.top?.PaperExtractor),
        floatingWindow: !!(window.FloatingWindow || window.top?.FloatingWindow)
    });
});

// 自动模式处理
let autoMode = false;

// 加载自动模式设置
function loadAutoModeSettings() {
    chrome.storage.sync.get(['autoMode'], (result) => {
        autoMode = Boolean(result.autoMode);
        console.log('Auto mode loaded:', autoMode);
    });
}

// 监听自动模式变化
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'sync' && changes.autoMode) {
        autoMode = Boolean(changes.autoMode.newValue);
        console.log('Auto mode changed:', autoMode);
    }
});

// 添加到 content.js
async function initializeWithRetry(maxRetries = 3) {
    for (let i = 0; i < maxRetries; i++) {
        try {
            if (window.location.pathname.includes('/pdf/')) {
                const FloatingWindowClass = await waitForFloatingWindow();
                const floatingWindow = new FloatingWindowClass();
                await floatingWindow.initializeAsync();
                console.log('Successfully initialized FloatingWindow');
                return;
            }
        } catch (error) {
            console.error(`Initialization attempt ${i + 1} failed:`, error);
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
    }
    console.error('Failed to initialize after multiple attempts');
}

// 使用重试机制
if (window.location.pathname.includes('/pdf/')) {
    window.addEventListener('load', () => {
        initializeWithRetry();
    });
}

// 修改页面加载完成后的处理
window.addEventListener('load', () => {
    loadAutoModeSettings();

    if (autoMode) {
        const extractor = new PaperExtractor();
        extractor.extractAll()
            .then(paperInfo => {
                const hasContent = Object.values(paperInfo).some(value => 
                    value && (Array.isArray(value) ? value.length > 0 : value.trim() !== '')
                );
                
                if (hasContent) {
                    chrome.runtime.sendMessage({
                        action: 'paperDetected',
                        data: paperInfo
                    }, response => {
                        if (chrome.runtime.lastError) {
                            console.error('Error sending paper info:', chrome.runtime.lastError);
                        } else {
                            console.log('Paper info sent successfully:', response);
                        }
                    });
                } else {
                    console.log('No paper information detected on this page');
                }
            })
            .catch(error => {
                console.error('Error during auto extraction:', error);
            });
    }
});

// 正确导出 PaperExtractor 类
if (typeof window !== 'undefined') {
    window.PaperExtractor = PaperExtractor;
}

